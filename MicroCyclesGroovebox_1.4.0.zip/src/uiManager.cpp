/*** Last Changed: 2026-06-21 - 14:26 ***/
#include "uiManager.h"
#include "uiPatternGroupInput.h"
#include "uiCardStorageActions.h"
#include "uiCardStorageMenu.h"
#include "uiGrooveboxScreen.h"
#include "uiSystemSettingsMenu.h"
#include "uiSequencerInput.h"
#include "DisplayDriverClass.h"

#include "DisplayDriverClass.h"
#include "audioEngine.h"
#include "colorSettings.h"
#include "settingsStore.h"
#include "sampleManager.h"
#include "audioEngine.h"
#include "sequencer.h"
#include "systemManager.h"
#include "InputClass.h"
#include "progVersion.h"

#include <Arduino.h>
#include <ctype.h>
#include <esp_log.h>

//-- Logging tag.
static const char* logTag = "UiManager";

//-- UI refresh cadence.
static const uint32_t uiRefreshIntervalMs = 50;

//-- Contextual step parameter pages.
enum ParameterPage : uint8_t
{
  parameterPageTrig = 0,
  parameterPageVelocity,
  parameterPagePitch,
  parameterPageDecay,
  parameterPageProbability,
  parameterPageMute,
  parameterPageChain,
  parameterPageCount
};

//-- Settings menu entries.
static const int settingsEntryCount = 14;
//-- Special list mode for Card pattern groups.
static const int patternListModeCardGroups = 1001;
static const int patternListModeMemoryPatterns = 1002;
//-- Card Storage menu item count.
static const int cardStorageMenuEntryCount = 7;
static const int sampleSetListMaxEntries = 9;
static const int settingsFirstActionIndex = 3;
static const int patternListMaxEntries = static_cast<int>(patternStoreMaxEntries * 2U);
static const int menuVisibleLineCount = 9;

enum class PatternEntrySource : uint8_t
{
  Local = 0,
  Card = 1
};

//-- Track labels for sequencer page.
static const char* trackNames[sequencerTrackCount] = {"KICK", "SNARE", "CH", "OH", "TONE", "METAL"};

//-- UI state container.
struct UiState
{
  bool menuOpen;
  bool tempoEditOpen;
  bool editPopupOpen;
  bool editPopupValueEdit;
  bool editPopupValueChanged;
  int editPopupSelection;
  uint8_t editPopupChainFocus;
  int tempoEditSelection;
  bool tempoEditValueEdit;
  uint8_t masterGainPercent;
  bool masterGainDirty;
  bool wifiManagerConfirmOpen;
  bool eraseWifiConfirmOpen;
  bool patternListOpen;
  bool patternDeleteMode;
  int patternListSourceFilter;
  bool patternListNeedsRefresh;
  bool patternStatusOpen;
  bool wifiManagerWaitingForCredentials;
  bool wifiManagerPortalSeenActive;
  bool eraseWifiRestartPending;
  int wifiManagerConfirmSelection;
  int eraseWifiConfirmSelection;
  int menuSelection;
  int menuFirstVisibleIndex;
  int patternListSelection;
  int patternListFirstVisibleIndex;
  int patternCount;
  uint32_t patternStatusUntilMs;
  uint32_t eraseWifiRestartAtMs;
  uint32_t lastDrawMs;
  bool dirty;
  uint8_t parameterPageIndex;
  String activePatternName;
  String patternStatusText;
  String chainTargetPatternName;
  bool chainTargetValid;
  bool chainSettingsDirty;
  bool patternGroupDirty;
  String patternChainTargets[patternListMaxEntries];
  bool patternHasChainTarget[patternListMaxEntries];
  String chainSeriesPatternNames[patternStoreMaxEntries];
  int chainSeriesPatternCount;
  char chainSeriesPatternLetter;
  bool chainSeriesPatternCacheValid;
  String chainSlotTargetPatternNames[sequencerPatternCount];
  bool chainSlotChainEnabled[sequencerPatternCount];
  String patternNames[patternListMaxEntries];
  String patternListDisplayItems[patternListMaxEntries];
  PatternEntrySource patternSources[patternListMaxEntries];
  String chainSlotPatternNames[sequencerPatternCount];
  bool localStorageMenuOpen;
  bool cardStorageMenuOpen;
  int cardStorageMenuSelection;
  int cardStorageMenuFirstVisibleIndex;
  bool sampleSetListOpen;
  int sampleSetListSelection;
  int sampleSetListFirstVisibleIndex;
  int sampleSetCount;
  String sampleSetNames[sampleSetListMaxEntries];
  String sampleSetDisplayItems[sampleSetListMaxEntries];
};

//-- Encoder handling state.
enum class UiEncoderState : uint8_t
{
  PatternGroupInput,
  Menu,
  TempoEdit,
  EditPopup,
  Groovebox

}; //   UiEncoderState

//-- Runtime state.
static UiState uiState;
static uint8_t lastSequencerStep = 0xFF;
static uint8_t lastSequencerCursor = 0xFF;
static bool lastSequencerPlaying = false;
static uint8_t lastSequencerActivePatternIndex = 0xFF;
static bool sequencerScreenDrawn = false;
static String lastSequencerFooterLine;
static String patternScanBuffer[patternStoreMaxEntries];

//-- Maximum item text length inside list rows (display width is 26 chars).
static const size_t listRowContentChars = 24;

//-- Maximum footer text length drawn directly on screen.
static const size_t footerLineChars = 26;

//-- Conservative estimate used to map LittleFS free bytes to writable patterns.
static const size_t estimatedPatternBytes = 9957;

//-- Edit popup entries mapped 1:1 to ParameterPage values.
static const uint8_t editPopupPageMap[] = {parameterPageVelocity, parameterPagePitch,
                                           parameterPageDecay,    parameterPageProbability,
                                           parameterPageMute,     parameterPageChain};

static const int editPopupEntryCount =
    static_cast<int>(sizeof(editPopupPageMap) / sizeof(editPopupPageMap[0]));

//-- CHAIN value-edit focus fields.
static const uint8_t chainPopupFocusEnable = 0;
static const uint8_t chainPopupFocusLength = 1;
static const uint8_t chainPopupFocusPattern = 2;

//-- Select next/previous chain target pattern in the same series letter.
static void selectNextPatternInSeries(int direction);

//-- Rebuild cached same-series chain target list.
static void refreshChainSeriesPatternCache();

//-- Build a canonical pNN name for one zero-based pattern slot.
static String buildPatternNameForSlot(uint8_t slotIndex);

//-- Load one Card pattern group directly into sequencer memory by group name.
static bool loadCardPatternGroupIntoMemory(const String& groupName, bool showStatus);

//-- Show temporary pattern/status popup.
static void showPatternStatus(const String& text, uint32_t durationMs);

//-- Flush pending chain settings to the active pattern.
static void flushPendingChainSettings();

//-- Count loaded pattern slots currently known by the UI.
static uint8_t getLoadedPatternSlotCount()
{
  uint8_t loadedPatternCount = 0;

  for (uint8_t slotIndex = 0; slotIndex < sequencerPatternCount; slotIndex++)
  {
    if (!uiState.chainSlotPatternNames[slotIndex].isEmpty())
    {
      loadedPatternCount = static_cast<uint8_t>(slotIndex + 1U);
    }
  }

  if (loadedPatternCount < 1)
  {
    loadedPatternCount = 1;
  }

  return loadedPatternCount;

} //   getLoadedPatternSlotCount()

//-- Return pattern slot number from pNN name.
static int patternSlotNumberFromName(const String& patternName)
{
  String normalizedName = patternName;

  if (normalizedName.endsWith(".json"))
  {
    normalizedName = normalizedName.substring(0, normalizedName.length() - 5);
  }

  if (normalizedName.length() != 3)
  {
    return -1;
  }

  if (normalizedName[0] != 'p' && normalizedName[0] != 'P')
  {
    return -1;
  }

  if (!isDigit(normalizedName[1]) || !isDigit(normalizedName[2]))
  {
    return -1;
  }

  int slotNumber = normalizedName.substring(1).toInt();

  if (slotNumber < 1)
  {
    return -1;
  }

  return slotNumber;

} //   patternSlotNumberFromName()

//-- Resolve pNN pattern name to zero-based RAM slot index.
static bool patternSlotIndexFromName(const String& patternName, uint8_t& outSlotIndex)
{
  int slotNumber = patternSlotNumberFromName(patternName);

  if (slotNumber < 1)
  {
    return false;
  }

  if (slotNumber > sequencerPatternCount)
  {
    return false;
  }

  outSlotIndex = static_cast<uint8_t>(slotNumber - 1);

  return true;

} //   patternSlotIndexFromName()

//-- Persist the currently active pattern name for one in-memory chain slot.
static void assignActivePatternNameToCurrentSlot()
{
  SequencerView view;

  sequencerGetView(view);

  if (view.activePatternIndex < sequencerPatternCount)
  {
    uiState.chainSlotPatternNames[view.activePatternIndex] = uiState.activePatternName;
  }

} //   assignActivePatternNameToCurrentSlot()

//-- Apply slot name back to active pattern label when known.
static void syncActivePatternNameFromSlot(uint8_t slotIndex)
{
  if (slotIndex >= sequencerPatternCount)
  {
    return;
  }

  if (!uiState.chainSlotPatternNames[slotIndex].isEmpty())
  {
    uiState.activePatternName = uiState.chainSlotPatternNames[slotIndex];
  }

} //   syncActivePatternNameFromSlot()

//-- Synchronize UI chain target names into the realtime sequencer table.
static void syncSequencerChainTargetsFromUi()
{
  uint8_t loadedPatternCount = getLoadedPatternSlotCount();

  sequencerSetLoadedPatternCount(loadedPatternCount);
  sequencerClearPatternChainTargets();

  for (uint8_t slotIndex = 0; slotIndex < loadedPatternCount; slotIndex++)
  {
    uint8_t targetSlotIndex = 0;
    String targetName = uiState.chainSlotTargetPatternNames[slotIndex];

    if (!uiState.chainSlotChainEnabled[slotIndex])
    {
      continue;
    }

    if (patternSlotIndexFromName(targetName, targetSlotIndex) &&
        targetSlotIndex < loadedPatternCount)
    {
      sequencerSetPatternChainTarget(slotIndex, targetSlotIndex, true);
    }
  }

} //   syncSequencerChainTargetsFromUi()

/*** no longer in use (??) *******
//-- Return true when every loaded pattern is part of the chain starting at p01.
static bool areAllLoadedPatternsIncludedInPlaybackChain()
{
  bool visited[sequencerPatternCount];
  uint8_t loadedPatternCount = getLoadedPatternSlotCount();
  uint8_t currentSlotIndex = 0;
  uint8_t visitedCount = 0;

  if (loadedPatternCount <= 1U)
  {
    return true;
  }

  for (uint8_t slotIndex = 0; slotIndex < sequencerPatternCount; slotIndex++)
  {
    visited[slotIndex] = false;
  }

  for (uint8_t guard = 0; guard < loadedPatternCount + 1U; guard++)
  {
    uint8_t nextSlotIndex = 0;
    String targetName;

    if (currentSlotIndex >= loadedPatternCount)
    {
      return false;
    }

    if (!visited[currentSlotIndex])
    {
      visited[currentSlotIndex] = true;
      visitedCount++;
    }

    targetName = uiState.chainSlotTargetPatternNames[currentSlotIndex];

    if (!patternSlotIndexFromName(targetName, nextSlotIndex))
    {
      return false;
    }

    if (nextSlotIndex >= loadedPatternCount)
    {
      return false;
    }

    currentSlotIndex = nextSlotIndex;

    if (currentSlotIndex == 0)
    {
      break;
    }
  }

  return visitedCount == loadedPatternCount;

} //   areAllLoadedPatternsIncludedInPlaybackChain()
 ****/

//-- Map current parameter page to popup selection index.
static int popupSelectionFromParameterPage(uint8_t parameterPage)
{
  for (int popupIndex = 0; popupIndex < editPopupEntryCount; popupIndex++)
  {
    if (editPopupPageMap[popupIndex] == parameterPage)
    {
      return popupIndex;
    }
  }

  return 0;

} //   popupSelectionFromParameterPage()

//-- Resolve popup selection index to parameter page.
static uint8_t popupSelectionToParameterPage(int popupSelection)
{
  if (popupSelection < 0 || popupSelection >= editPopupEntryCount)
  {
    return parameterPageVelocity;
  }

  return editPopupPageMap[popupSelection];

} //   popupSelectionToParameterPage()

//-- Return SampleId for one sequencer track index.
static SampleId sampleIdForTrackIndex(uint8_t trackIndex)
{
  if (trackIndex == 0)
  {
    return sampleKick;
  }
  else if (trackIndex == 1)
  {
    return sampleSnare;
  }
  else if (trackIndex == 2)
  {
    return sampleClosedHat;
  }
  else if (trackIndex == 3)
  {
    return sampleOpenHat;
  }
  else if (trackIndex == 4)
  {
    return sampleTone;
  }

  return sampleMetal;

} //   sampleIdForTrackIndex()

//-- Return choke group used for auditioning one track.
static uint8_t auditionChokeGroupForTrack(uint8_t trackIndex)
{
  if (trackIndex == 2 || trackIndex == 3)
  {
    return 1;
  }

  if (trackIndex == 5)
  {
    return 2;
  }

  return 0;

} //   auditionChokeGroupForTrack()

//-- Audition the currently selected edited step.
static void auditionCurrentEditedStep()
{
  SequencerView view;

  sequencerGetView(view);

  if (view.pattern == nullptr)
  {
    return;
  }

  if (view.selectedTrack >= sequencerTrackCount || view.cursorStep >= sequencerStepCount)
  {
    return;
  }

  const Step& selectedStep = view.pattern->tracks[view.selectedTrack].steps[view.cursorStep];

  if (!selectedStep.trigger)
  {
    return;
  }

  uint8_t auditionLevel = selectedStep.velocity;
  uint8_t auditionDecay = 100;
  int8_t auditionPitch = 0;

  if (selectedStep.lockEnabled)
  {
    auditionDecay = static_cast<uint8_t>(selectedStep.lockDecay);
    auditionPitch = selectedStep.lockPitch;
  }

  if (auditionLevel == 0)
  {
    auditionLevel = 1;
  }

  audioEngineTriggerSample(sampleIdForTrackIndex(view.selectedTrack), auditionLevel, 65535, 0,
                           auditionChokeGroupForTrack(view.selectedTrack), auditionDecay,
                           auditionPitch);

} //   auditionCurrentEditedStep()

//-- Audition the currently selected edited step twice when playback is stopped.
static void auditionCurrentEditedStepTwiceWhenStopped()
{
  SequencerView view;

  sequencerGetView(view);

  if (view.playing)
  {
    return;
  }

  auditionCurrentEditedStep();

  vTaskDelay(pdMS_TO_TICKS(150));

  auditionCurrentEditedStep();

} //   auditionCurrentEditedStepTwiceWhenStopped()

//-- Leave popup value-edit mode and audition the edited step when changed.
static void finishEditPopupValueEdit()
{
  bool shouldAudition = false;

  if (!uiState.editPopupValueEdit)
  {
    return;
  }

  shouldAudition = uiState.editPopupValueChanged;

  uiState.editPopupValueEdit = false;
  uiState.editPopupValueChanged = false;

  if (shouldAudition)
  {
    auditionCurrentEditedStepTwiceWhenStopped();
  }

  uiState.dirty = true;

} //   finishEditPopupValueEdit()

//-- Close edit popup and return to normal step navigation.
static void closeEditPopupAndReturnToStepNavigation()
{
  finishEditPopupValueEdit();

  flushPendingChainSettings();

  uiState.editPopupOpen = false;
  uiState.editPopupValueEdit = false;
  uiState.editPopupChainFocus = chainPopupFocusEnable;

  //-- Return to TRIG page so encoder rotation moves through steps again.
  uiState.parameterPageIndex = parameterPageTrig;

  uiState.dirty = true;

} //   closeEditPopupAndReturnToStepNavigation()

//-- Open edit popup for the current step, enabling the trigger first if needed.
static void openEditPopupForCurrentStep()
{
  SequencerView view;

  sequencerGetView(view);

  if (view.pattern == nullptr)
  {
    return;
  }

  if (view.selectedTrack >= sequencerTrackCount || view.cursorStep >= sequencerStepCount)
  {
    return;
  }

  if (!view.pattern->tracks[view.selectedTrack].steps[view.cursorStep].trigger)
  {
    sequencerToggleCurrentStep();
    sequencerGetView(view);

    uiState.patternGroupDirty = true;
  }

  uiState.editPopupSelection = popupSelectionFromParameterPage(uiState.parameterPageIndex);
  uiState.editPopupOpen = true;
  uiState.editPopupValueEdit = false;
  uiState.editPopupValueChanged = false;
  uiState.editPopupChainFocus = chainPopupFocusEnable;
  uiState.dirty = true;

} //   openEditPopupForCurrentStep()

//-- Apply encoder delta to selected popup value while value-edit mode is active.
static void applyEditPopupValueDelta(int delta)
{
  uint8_t pageIndex;
  SequencerView view;

  if (delta == 0)
  {
    return;
  }

  pageIndex = popupSelectionToParameterPage(uiState.editPopupSelection);

  if (pageIndex == parameterPageVelocity)
  {
    sequencerAdjustCurrentStepVelocity(delta > 0 ? 8 : -8);
    uiState.editPopupValueChanged = true;
  }
  else if (pageIndex == parameterPagePitch)
  {
    sequencerAdjustCurrentStepLockPitch(delta > 0 ? 1 : -1);
    uiState.editPopupValueChanged = true;
  }
  else if (pageIndex == parameterPageDecay)
  {
    sequencerAdjustCurrentStepLockDecay(delta > 0 ? 5 : -5);
    uiState.editPopupValueChanged = true;
  }
  else if (pageIndex == parameterPageProbability)
  {
    sequencerAdjustCurrentStepProbability(delta > 0 ? 5 : -5);
    uiState.editPopupValueChanged = true;
  }
  else if (pageIndex == parameterPageMute)
  {
    sequencerToggleCurrentStepMute();
    uiState.editPopupValueChanged = true;
  }
  else
  {
    sequencerGetView(view);

    if (uiState.editPopupChainFocus == chainPopupFocusLength)
    {
      uint8_t loadedPatternCount = getLoadedPatternSlotCount();

      if (loadedPatternCount < 1)
      {
        loadedPatternCount = 1;
      }

      if (delta > 0)
      {
        if (view.chainLength < loadedPatternCount)
        {
          sequencerAdjustChainLength(1);
          uiState.editPopupValueChanged = true;
        }
      }
      else
      {
        if (view.chainLength > 1U)
        {
          sequencerAdjustChainLength(-1);
          uiState.editPopupValueChanged = true;
        }
      }
    }
    else if (uiState.editPopupChainFocus == chainPopupFocusPattern)
    {
      selectNextPatternInSeries(delta > 0 ? 1 : -1);
      uiState.editPopupValueChanged = true;
    }
    else
    {
      if (view.chainEnabled)
      {
        sequencerToggleChainEnabled();
      }
      else
      {
        uint8_t loadedPatternCount = getLoadedPatternSlotCount();

        if (loadedPatternCount > 1U && view.chainLength <= 1U)
        {
          sequencerAdjustChainLength(1);
        }

        sequencerToggleChainEnabled();
      }

      uiState.editPopupValueChanged = true;
    }

    uiState.chainSettingsDirty = true;
  }

  uiState.patternGroupDirty = true;
  uiState.dirty = true;

} //   applyEditPopupValueDelta()

//-- Clip list item text to fit 26-char display with cursor wrappers.
static String fitListRowText(const String& text)
{
  if (text.length() <= listRowContentChars)
  {
    return text;
  }

  return text.substring(0, listRowContentChars);

} //   fitListRowText()

//-- Rebuild cached chain target list from loaded RAM pattern slots.
static void refreshChainSeriesPatternCache()
{
  uiState.chainSeriesPatternCount = 0;
  uiState.chainSeriesPatternLetter = 'p';
  uiState.chainSeriesPatternCacheValid = false;

  for (uint8_t slotIndex = 0; slotIndex < sequencerPatternCount; slotIndex++)
  {
    String slotName = uiState.chainSlotPatternNames[slotIndex];

    if (slotName.isEmpty())
    {
      continue;
    }

    if (slotName == uiState.activePatternName)
    {
      continue;
    }

    if (patternSlotNumberFromName(slotName) < 1)
    {
      continue;
    }

    uiState.chainSeriesPatternNames[uiState.chainSeriesPatternCount] = slotName;
    uiState.chainSeriesPatternCount++;

    if (uiState.chainSeriesPatternCount >= static_cast<int>(patternStoreMaxEntries))
    {
      break;
    }
  }

  uiState.chainSeriesPatternCacheValid = true;

} //   refreshChainSeriesPatternCache()

//-- Return available loaded pNN targets excluding the active pattern name.
static int getAvailablePatternsForCurrentSeries(String outNames[patternStoreMaxEntries])
{
  if (!uiState.chainSeriesPatternCacheValid)
  {
    refreshChainSeriesPatternCache();
  }

  for (int nameIndex = 0; nameIndex < uiState.chainSeriesPatternCount; nameIndex++)
  {
    outNames[nameIndex] = uiState.chainSeriesPatternNames[nameIndex];
  }

  return uiState.chainSeriesPatternCount;

} //   getAvailablePatternsForCurrentSeries()

//-- Validate the current chain target against loaded RAM pattern slots.
static bool isCurrentChainTargetValid()
{
  String availableNames[patternStoreMaxEntries];
  int availableCount;

  if (uiState.chainTargetPatternName.isEmpty())
  {
    return false;
  }

  availableCount = getAvailablePatternsForCurrentSeries(availableNames);

  for (int nameIndex = 0; nameIndex < availableCount; nameIndex++)
  {
    if (availableNames[nameIndex] == uiState.chainTargetPatternName)
    {
      return true;
    }
  }

  return false;

} //   isCurrentChainTargetValid()

//-- Load chain settings for active RAM pattern without touching LittleFS.
static void loadChainSettingsForActivePattern()
{
  SequencerView view;

  uiState.chainTargetValid = false;
  uiState.chainSettingsDirty = false;
  uiState.chainTargetPatternName = "";

  sequencerGetView(view);

  if (view.activePatternIndex >= sequencerPatternCount)
  {
    return;
  }

  refreshChainSeriesPatternCache();

  if (!uiState.chainSlotTargetPatternNames[view.activePatternIndex].isEmpty())
  {
    uiState.chainTargetPatternName = uiState.chainSlotTargetPatternNames[view.activePatternIndex];
    uiState.chainTargetValid = isCurrentChainTargetValid();
  }

  if (view.chainEnabled != uiState.chainSlotChainEnabled[view.activePatternIndex])
  {
    sequencerToggleChainEnabled();
  }

} //   loadChainSettingsForActivePattern()

//-- Save active-pattern chain settings into RAM bookkeeping only.
static void saveChainSettingsForPattern()
{
  SequencerView view;

  sequencerGetView(view);

  if (view.activePatternIndex >= sequencerPatternCount)
  {
    return;
  }

  uiState.chainSlotPatternNames[view.activePatternIndex] = uiState.activePatternName;
  uiState.chainSlotChainEnabled[view.activePatternIndex] = view.chainEnabled;

  if (uiState.chainTargetValid)
  {
    uiState.chainSlotTargetPatternNames[view.activePatternIndex] = uiState.chainTargetPatternName;
  }
  else
  {
    uiState.chainSlotTargetPatternNames[view.activePatternIndex] = "";
    uiState.chainSlotChainEnabled[view.activePatternIndex] = false;
  }

  syncSequencerChainTargetsFromUi();

  uiState.patternGroupDirty = true;

} //   saveChainSettingsForPattern()

//-- Commit pending chain settings to storage when UI leaves edit interactions.
static void flushPendingChainSettings()
{
  if (!uiState.chainSettingsDirty)
  {
    return;
  }

  saveChainSettingsForPattern();
  uiState.chainSettingsDirty = false;

} //   flushPendingChainSettings()

//-- Select next/previous chain target pattern in the same series letter.
static void selectNextPatternInSeries(int direction)
{
  String availableNames[patternStoreMaxEntries];
  int availableCount;
  int currentIndex = -1;

  if (direction == 0)
  {
    return;
  }

  availableCount = getAvailablePatternsForCurrentSeries(availableNames);

  if (availableCount <= 0)
  {
    uiState.chainTargetValid = false;
    return;
  }

  for (int nameIndex = 0; nameIndex < availableCount; nameIndex++)
  {
    if (availableNames[nameIndex] == uiState.chainTargetPatternName)
    {
      currentIndex = nameIndex;
      break;
    }
  }

  if (currentIndex < 0)
  {
    currentIndex = (direction > 0) ? 0 : (availableCount - 1);
  }
  else
  {
    currentIndex += (direction > 0) ? 1 : -1;

    if (currentIndex < 0)
    {
      currentIndex = availableCount - 1;
    }
    else if (currentIndex >= availableCount)
    {
      currentIndex = 0;
    }
  }

  uiState.chainTargetPatternName = availableNames[currentIndex];
  uiState.chainTargetValid = true;

} //   selectNextPatternInSeries()

//-- Draw status popup overlay with up to 3 wrapped lines split by '\n'.
static void drawPatternStatusPopupOverlay()
{
  String popupLines[3];
  int lineCount = 0;
  int cursor_start = 0;

  while (lineCount < 3)
  {
    int newLineIndex = uiState.patternStatusText.indexOf('\n', cursor_start);

    if (newLineIndex < 0)
    {
      String tail = uiState.patternStatusText.substring(cursor_start);

      if (tail.length() > 0)
      {
        popupLines[lineCount++] = fitListRowText(tail);
      }

      break;
    }

    String segment = uiState.patternStatusText.substring(cursor_start, newLineIndex);
    popupLines[lineCount++] = fitListRowText(segment);
    cursor_start = newLineIndex + 1;
  }

  if (lineCount == 0)
  {
    popupLines[0] = "Done";
    lineCount = 1;
  }

  display.drawSelectionOverlay("Status", popupLines, static_cast<size_t>(lineCount), 0);

} //   drawPatternStatusPopupOverlay()

//-- Show temporary status and return to settings menu after timeout.
static void showPatternStatus(const String& statusText, uint32_t durationMs)
{
  uiState.patternStatusText = statusText;
  uiState.patternStatusOpen = true;
  uiState.patternStatusUntilMs = millis() + durationMs;

} //   showPatternStatus()

//-- Draw an immediate busy popup before a blocking SD action starts.
static void drawBusyPopupNow(const String& title, const String& message)
{
  String popupLines[2];

  popupLines[0] = fitListRowText(message);
  popupLines[1] = "Please wait...";

  display.drawSelectionOverlay(title.c_str(), popupLines, 2, 0);

  delay(50);

} //   drawBusyPopupNow()

//-- Show a clear popup when an SD action is requested without an inserted card.
static bool ensureSdCardPresentForUiAction(const String& actionName);

//-- Save current runtime settings to storage.
static void saveRuntimeSettingsFromCurrentState();

//-- Create one empty pattern payload for a new group.
static void buildEmptyPatternData(PatternData& patternData)
{
  patternData.bpm = 120;
  patternData.swingPercent = 8;
  patternData.chainEnabled = false;
  patternData.chainLength = 1;
  patternData.chainTarget = "";

  for (uint8_t trackIndex = 0; trackIndex < sequencerTrackCount; trackIndex++)
  {
    patternData.pattern.tracks[trackIndex].mute = false;

    for (uint8_t stepIndex = 0; stepIndex < sequencerStepCount; stepIndex++)
    {
      patternData.pattern.tracks[trackIndex].steps[stepIndex].trigger = false;
      patternData.pattern.tracks[trackIndex].steps[stepIndex].mute = false;
      patternData.pattern.tracks[trackIndex].steps[stepIndex].velocity = 128;
      patternData.pattern.tracks[trackIndex].steps[stepIndex].probability = 100;
      patternData.pattern.tracks[trackIndex].steps[stepIndex].lockEnabled = false;
      patternData.pattern.tracks[trackIndex].steps[stepIndex].lockPitch = 0;
      patternData.pattern.tracks[trackIndex].steps[stepIndex].lockDecay = 100;
    }
  }

} //   buildEmptyPatternData()

//-- Create a new Card pattern group with one empty p01 pattern.
static bool createNewPatternGroupOnCard(const String& groupName, String& statusMessage)
{
  PatternData patternData;

  if (!ensureSdCardPresentForUiAction("New Group"))
  {
    statusMessage = "No SD card";
    return false;
  }

  buildEmptyPatternData(patternData);

  drawBusyPopupNow("New Group", "Creating " + groupName);

  if (!settingsStoreSavePatternToCard(groupName, "p01", patternData))
  {
    statusMessage = "Create failed\n" + groupName;
    return false;
  }

  if (!loadCardPatternGroupIntoMemory(groupName, false))
  {
    statusMessage = "Load failed\n" + groupName;
    return false;
  }

  if (!settingsStoreSetActivePatternGroup(groupName))
  {
    statusMessage = "NVS save failed\n" + groupName;
    return false;
  }

  saveRuntimeSettingsFromCurrentState();

  uiState.activePatternName = "p01";
  uiState.patternGroupDirty = false;
  uiState.patternListNeedsRefresh = true;

  statusMessage = "Created group\n" + groupName;

  return true;

} //   createNewPatternGroupOnCard()

//-- Commit Rename, Copy or New pattern group input.
static void commitPatternGroupNameInput()
{
  String oldGroupName = settingsStoreGetActivePatternGroup();
  String newGroupName = uiPatternGroupInputGetTrimmedName();
  bool copyMode = uiPatternGroupInputIsCopyMode();
  bool newGroupMode = uiPatternGroupInputIsNewGroupMode();
  String statusMessage;
  bool success = false;

  if (newGroupName.isEmpty())
  {
    uiPatternGroupInputClose();
    showPatternStatus("Name empty", 2000);
    uiState.dirty = true;

    return;
  }

  //-- Close input first so the busy popup can be drawn before the SD action starts.
  uiPatternGroupInputClose();

  uiState.patternStatusOpen = false;
  uiState.patternStatusText = "";
  uiState.dirty = true;

  if (newGroupMode)
  {
    success = createNewPatternGroupOnCard(newGroupName, statusMessage);
  }
  else if (copyMode)
  {
    display.drawMessage("Copy Group", "Copying...");
    delay(50);
    success = uiCardStorageCopyPatternGroup(oldGroupName, newGroupName, statusMessage);
  }
  else
  {
    display.drawMessage("Rename Group", "Renaming...");
    delay(50);
    success = uiCardStorageRenamePatternGroup(oldGroupName, newGroupName, statusMessage);
  }

  if (!success)
  {
    showPatternStatus(statusMessage, 2500);
    uiState.dirty = true;

    return;
  }

  if (copyMode)
  {
    loadCardPatternGroupIntoMemory(newGroupName, false);
  }

  showPatternStatus(statusMessage, 2500);

  uiState.patternListNeedsRefresh = true;
  uiState.dirty = true;

} //   commitPatternGroupNameInput()

//-- Persist currently active editable system settings.
static void saveRuntimeSettingsFromCurrentState()
{
  RuntimeSettings settings;

  settings.displayRotation = static_cast<uint8_t>(displayGetRotation());
  settings.themeColorIndex = displayGetThemeColorIndex();
  settings.encoderDirectionReversed = input.getEncoderDirectionReversed();
  settings.activePatternName = uiState.activePatternName;

  if (!settingsStoreSaveRuntimeSettings(settings))
  {
    ESP_LOGW(logTag, "Failed to persist runtime settings");
  }

} //   saveRuntimeSettingsFromCurrentState()

//-- Refresh pattern list from selected source.
static void refreshPatternList()
{
  size_t listedCount = 0;
  String activeGroupName = settingsStoreGetActivePatternGroup();

  uiState.patternCount = 0;

  if (uiState.patternListSourceFilter == patternListModeMemoryPatterns)
  {
    uint8_t loadedPatternCount = getLoadedPatternSlotCount();

    for (uint8_t slotIndex = 0;
         slotIndex < loadedPatternCount && uiState.patternCount < patternListMaxEntries;
         slotIndex++)
    {
      uiState.patternNames[uiState.patternCount] = buildPatternNameForSlot(slotIndex);
      uiState.patternSources[uiState.patternCount] = PatternEntrySource::Local;
      uiState.patternCount++;
    }

    if (uiState.patternListSelection >= uiState.patternCount)
    {
      uiState.patternListSelection = (uiState.patternCount > 0) ? (uiState.patternCount - 1) : 0;
    }

    return;
  }

  if (uiState.patternListSourceFilter == patternListModeCardGroups)
  {
    if (settingsStoreListPatternGroupsOnCard(patternScanBuffer, patternStoreMaxEntries,
                                             listedCount))
    {
      for (size_t index = 0; index < listedCount && uiState.patternCount < patternListMaxEntries;
           index++)
      {
        if (uiState.patternDeleteMode && patternScanBuffer[index] == activeGroupName)
        {
          continue;
        }

        uiState.patternNames[uiState.patternCount] = patternScanBuffer[index];
        uiState.patternSources[uiState.patternCount] = PatternEntrySource::Card;
        uiState.patternCount++;
      }
    }

    for (int leftIndex = 0; leftIndex < uiState.patternCount; leftIndex++)
    {
      for (int rightIndex = leftIndex + 1; rightIndex < uiState.patternCount; rightIndex++)
      {
        if (uiState.patternNames[rightIndex].compareTo(uiState.patternNames[leftIndex]) < 0)
        {
          String temporaryName = uiState.patternNames[leftIndex];
          PatternEntrySource temporarySource = uiState.patternSources[leftIndex];

          uiState.patternNames[leftIndex] = uiState.patternNames[rightIndex];
          uiState.patternSources[leftIndex] = uiState.patternSources[rightIndex];

          uiState.patternNames[rightIndex] = temporaryName;
          uiState.patternSources[rightIndex] = temporarySource;
        }
      }
    }

    if (uiState.patternListSelection >= uiState.patternCount)
    {
      uiState.patternListSelection = (uiState.patternCount > 0) ? (uiState.patternCount - 1) : 0;
    }

    for (int patternIndex = 0; patternIndex < patternListMaxEntries; patternIndex++)
    {
      uiState.patternHasChainTarget[patternIndex] = false;
      uiState.patternChainTargets[patternIndex] = "";
    }

    return;
  }

  uiState.patternListSelection = 0;
  uiState.patternListFirstVisibleIndex = 0;

  for (int patternIndex = 0; patternIndex < patternListMaxEntries; patternIndex++)
  {
    uiState.patternHasChainTarget[patternIndex] = false;
    uiState.patternChainTargets[patternIndex] = "";
  }

} //   refreshPatternList()

//-- Legacy compatibility: load one selected Card pattern into the active RAM slot.
static bool loadSelectedPattern()
{
  PatternData patternData;
  SequencerView view;
  String groupName = settingsStoreGetActivePatternGroup();

  if (uiState.patternCount <= 0 || uiState.patternListSelection < 0 ||
      uiState.patternListSelection >= uiState.patternCount)
  {
    return false;
  }

  if (groupName.isEmpty())
  {
    return false;
  }

  if (uiState.patternSources[uiState.patternListSelection] != PatternEntrySource::Card)
  {
    return false;
  }

  String selectedName = uiState.patternNames[uiState.patternListSelection];

  if (!settingsStoreLoadPatternFromCard(groupName, selectedName, patternData))
  {
    return false;
  }

  sequencerGetView(view);
  sequencerImportPatternToSlot(view.activePatternIndex, patternData);

  uiState.activePatternName = selectedName;
  assignActivePatternNameToCurrentSlot();

  if (view.activePatternIndex < sequencerPatternCount)
  {
    uiState.chainSlotTargetPatternNames[view.activePatternIndex] = patternData.chainTarget;
  }

  refreshChainSeriesPatternCache();
  loadChainSettingsForActivePattern();
  syncSequencerChainTargetsFromUi();
  saveRuntimeSettingsFromCurrentState();

  return true;

} //   loadSelectedPattern()

//-- Build a canonical pNN name for one zero-based pattern slot.
static String buildPatternNameForSlot(uint8_t slotIndex)
{
  char patternName[8];

  snprintf(patternName, sizeof(patternName), "p%02u", static_cast<unsigned>(slotIndex + 1U));

  return String(patternName);

} //   buildPatternNameForSlot()

//-- Rebuild loaded RAM pattern names after add/delete operations.
static void rebuildLoadedPatternNames(uint8_t loadedPatternCount)
{
  if (loadedPatternCount > sequencerPatternCount)
  {
    loadedPatternCount = sequencerPatternCount;
  }

  for (uint8_t slotIndex = 0; slotIndex < sequencerPatternCount; slotIndex++)
  {
    if (slotIndex < loadedPatternCount)
    {
      uiState.chainSlotPatternNames[slotIndex] = buildPatternNameForSlot(slotIndex);
    }
    else
    {
      uiState.chainSlotPatternNames[slotIndex] = "";
      uiState.chainSlotTargetPatternNames[slotIndex] = "";
    }
  }

} //   rebuildLoadedPatternNames()

//-- Add a new RAM pattern after the last loaded pattern by copying the previous pattern.
static bool addPatternInMemory()
{
  PatternData patternData;
  SequencerView view;
  uint8_t loadedPatternCount = getLoadedPatternSlotCount();
  uint8_t sourceSlotIndex = 0;
  uint8_t newSlotIndex = loadedPatternCount;
  String newPatternName;

  sequencerGetView(view);

  if (view.playing)
  {
    sequencerStopImmediately();
  }

  flushPendingChainSettings();

  if (loadedPatternCount >= sequencerPatternCount)
  {
    showPatternStatus("Pattern memory\nfull", 2500);
    return false;
  }

  if (loadedPatternCount > 0)
  {
    sourceSlotIndex = static_cast<uint8_t>(loadedPatternCount - 1U);
  }

  sequencerExportPatternFromSlot(sourceSlotIndex, patternData);

  newPatternName = buildPatternNameForSlot(newSlotIndex);

  for (uint8_t trackIndex = 0; trackIndex < sequencerTrackCount; trackIndex++)
  {
    patternData.pattern.tracks[trackIndex].mute = false;

    for (uint8_t stepIndex = 0; stepIndex < sequencerStepCount; stepIndex++)
    {
      patternData.pattern.tracks[trackIndex].steps[stepIndex].velocity = 100;
    }
  }

  patternData.chainEnabled = true;
  patternData.chainLength = static_cast<uint8_t>(loadedPatternCount + 1U);
  patternData.chainTarget = newPatternName;

  sequencerImportPatternToSlot(newSlotIndex, patternData);
  sequencerSetLoadedPatternCount(static_cast<uint8_t>(loadedPatternCount + 1U));
  sequencerSetActivePatternIndex(newSlotIndex);

  uiState.chainSlotPatternNames[newSlotIndex] = newPatternName;
  uiState.chainSlotTargetPatternNames[newSlotIndex] = newPatternName;
  uiState.activePatternName = newPatternName;
  uiState.chainTargetPatternName = newPatternName;
  uiState.chainTargetValid = true;
  uiState.chainSettingsDirty = true;

  refreshChainSeriesPatternCache();
  syncSequencerChainTargetsFromUi();
  loadChainSettingsForActivePattern();

  showPatternStatus("Added pattern\n" + uiState.activePatternName, 2000);

  uiState.patternListNeedsRefresh = true;
  uiState.dirty = true;

  return true;

} //   addPatternInMemory()

//-- Open RAM pattern delete selector.
static void openDeletePatternFromMemory()
{
  uiState.patternListOpen = true;
  uiState.patternDeleteMode = true;
  uiState.patternListSourceFilter = patternListModeMemoryPatterns;
  uiState.patternListSelection = 0;
  uiState.patternListFirstVisibleIndex = 0;
  uiState.patternListNeedsRefresh = true;

} //   openDeletePatternFromMemory()

//-- Delete selected RAM pattern and compact remaining RAM patterns.
static bool deleteSelectedPatternFromMemory()
{
  SequencerView view;
  uint8_t loadedPatternCount = getLoadedPatternSlotCount();
  uint8_t deleteSlotIndex;

  if (uiState.patternCount <= 0 || uiState.patternListSelection < 0 ||
      uiState.patternListSelection >= uiState.patternCount)
  {
    return false;
  }

  if (loadedPatternCount <= 1U)
  {
    showPatternStatus("Cannot delete\nlast pattern", 2500);
    return false;
  }

  deleteSlotIndex = static_cast<uint8_t>(uiState.patternListSelection);

  sequencerGetView(view);

  if (view.playing)
  {
    sequencerStopImmediately();
  }

  flushPendingChainSettings();

  sequencerDeletePatternSlot(deleteSlotIndex, loadedPatternCount);

  loadedPatternCount--;

  rebuildLoadedPatternNames(loadedPatternCount);
  sequencerSetLoadedPatternCount(loadedPatternCount);

  sequencerGetView(view);

  uiState.activePatternName = buildPatternNameForSlot(view.activePatternIndex);
  uiState.chainTargetPatternName = "";
  uiState.chainTargetValid = false;
  uiState.chainSettingsDirty = false;

  refreshChainSeriesPatternCache();
  loadChainSettingsForActivePattern();
  syncSequencerChainTargetsFromUi();

  uiState.patternListNeedsRefresh = true;
  uiState.dirty = true;

  showPatternStatus("Deleted pattern", 2000);

  return true;

} //   deleteSelectedPatternFromMemory()

//-- Delete one selected pattern from RAM or one Card group.
static bool deleteSelectedPattern(String* outDeletedName = nullptr,
                                  PatternEntrySource* outDeletedSource = nullptr)
{
  PatternEntrySource selectedSource;
  String selectedName;

  if (uiState.patternCount <= 0 || uiState.patternListSelection < 0 ||
      uiState.patternListSelection >= uiState.patternCount)
  {
    return false;
  }

  selectedName = uiState.patternNames[uiState.patternListSelection];
  selectedSource = uiState.patternSources[uiState.patternListSelection];

  if (outDeletedName != nullptr)
  {
    *outDeletedName = selectedName;
  }

  if (outDeletedSource != nullptr)
  {
    *outDeletedSource = selectedSource;
  }

  if (uiState.patternListSourceFilter == patternListModeMemoryPatterns)
  {
    return deleteSelectedPatternFromMemory();
  }

  if (uiState.patternListSourceFilter == patternListModeCardGroups &&
      selectedSource == PatternEntrySource::Card)
  {
    String activeGroupName = settingsStoreGetActivePatternGroup();

    if (selectedName == activeGroupName)
    {
      return false;
    }

    return settingsStoreDeletePatternGroupFromCard(selectedName);
  }

  return false;

} //   deleteSelectedPattern()

//-- Move Groovebox cursor across tracks and loaded pattern slots.
static void moveGrooveboxCursorAcrossPatterns(int delta)
{
  SequencerView viewBefore;
  SequencerView viewAfter;
  uint8_t loadedPatternCount = getLoadedPatternSlotCount();

  flushPendingChainSettings();

  sequencerGetView(viewBefore);

  sequencerMoveTrackAndPattern(delta, loadedPatternCount);

  sequencerGetView(viewAfter);

  uiState.activePatternName = buildPatternNameForSlot(viewAfter.activePatternIndex);

  loadChainSettingsForActivePattern();

  if (viewBefore.playing && !viewBefore.chainEnabled &&
      viewBefore.activePatternIndex != viewAfter.activePatternIndex)
  {
    sequencerRequestPatternSwitchAfterCurrentPattern(viewAfter.activePatternIndex);
  }

  uiState.dirty = true;

} //   moveGrooveboxCursorAcrossPatterns()

//-- Show a clear popup when an SD action is requested without an inserted card.
static bool ensureSdCardPresentForUiAction(const String& actionName)
{
  if (sampleManagerIsSdCardInserted())
  {
    return true;
  }

  showPatternStatus(actionName + "\nNo SD card", 3000);
  return false;

} //   ensureSdCardPresentForUiAction()

//-- Load selected Card pattern group.
static bool loadSelectedCardPatternGroup()
{
  SequencerView view;

  if (!ensureSdCardPresentForUiAction("Load Group"))
  {
    return false;
  }

  if (uiState.patternCount <= 0 || uiState.patternListSelection < 0 ||
      uiState.patternListSelection >= uiState.patternCount)
  {
    return false;
  }

  String selectedGroupName = uiState.patternNames[uiState.patternListSelection];

  sequencerGetView(view);

  if (view.playing)
  {
    sequencerStopImmediately();
  }

  uiState.patternListOpen = false;
  uiState.cardStorageMenuOpen = false;
  uiState.dirty = true;

  drawBusyPopupNow("Load Group", "Loading " + selectedGroupName);

  if (!loadCardPatternGroupIntoMemory(selectedGroupName, false))
  {
    return false;
  }

  if (!settingsStoreSetActivePatternGroup(selectedGroupName))
  {
    showPatternStatus("NVS save failed\n" + selectedGroupName, 2500);
    return false;
  }

  saveRuntimeSettingsFromCurrentState();

  ESP_LOGI(logTag, "Active Card pattern group stored in NVS: %s", selectedGroupName.c_str());

  return true;

} //   loadSelectedCardPatternGroup()

//-- Load one Card pattern group directly into sequencer memory by group name.
static bool loadCardPatternGroupIntoMemory(const String& groupName, bool showStatus)
{
  PatternData patternData;
  String cardPatternNames[patternStoreMaxEntries];
  size_t cardPatternCount = 0;

  if (groupName.isEmpty())
  {
    if (showStatus)
    {
      showPatternStatus("No active\ngroup", 2500);
    }

    return false;
  }

  displayBootLogInfo("Group " + groupName);

  if (!settingsStoreListPatternsInGroupOnCard(groupName, cardPatternNames, patternStoreMaxEntries,
                                              cardPatternCount))
  {
    if (showStatus)
    {
      showPatternStatus("List failed\n" + groupName, 2500);
    }

    return false;
  }

  if (cardPatternCount == 0)
  {
    if (showStatus)
    {
      showPatternStatus("Empty group\n" + groupName, 2500);
    }

    return false;
  }

  for (uint8_t slotIndex = 0; slotIndex < sequencerPatternCount; slotIndex++)
  {
    uiState.chainSlotPatternNames[slotIndex] = "";
    uiState.chainSlotTargetPatternNames[slotIndex] = "";
    uiState.chainSlotChainEnabled[slotIndex] = false;
  }

  for (size_t patternIndex = 0;
       patternIndex < cardPatternCount && patternIndex < sequencerPatternCount; patternIndex++)
  {
    if (!settingsStoreLoadPatternFromCard(groupName, cardPatternNames[patternIndex], patternData))
    {
      if (showStatus)
      {
        showPatternStatus("Load failed\n" + cardPatternNames[patternIndex], 2500);
      }

      return false;
    }

    displayBootLogInfo("Pattern " + cardPatternNames[patternIndex]);

    sequencerImportPatternToSlot(static_cast<uint8_t>(patternIndex), patternData);

    uiState.chainSlotPatternNames[patternIndex] = cardPatternNames[patternIndex];
    uiState.chainSlotTargetPatternNames[patternIndex] = patternData.chainTarget;
    uiState.chainSlotChainEnabled[patternIndex] = patternData.chainEnabled;
  }

  sequencerSetLoadedPatternCount(static_cast<uint8_t>(cardPatternCount));
  syncSequencerChainTargetsFromUi();
  sequencerSetActivePatternIndex(0);

  uiState.activePatternName = cardPatternNames[0];
  uiState.chainTargetPatternName = "";
  uiState.chainTargetValid = false;
  uiState.chainSettingsDirty = false;
  uiState.patternListNeedsRefresh = true;

  refreshChainSeriesPatternCache();
  loadChainSettingsForActivePattern();

  /***
    if (showStatus)
    {
      showPatternStatus("Loaded group\n" + groupName, 2500);
    }
  ***/

  ESP_LOGI(logTag, "Loaded Card group %s into RAM (%u patterns)", groupName.c_str(),
           static_cast<unsigned>(cardPatternCount));

  uiState.patternGroupDirty = false;

  return true;

} //   loadCardPatternGroupIntoMemory()

//-- Save loaded in-memory pattern slots to active Card pattern group.
static bool saveLoadedPatternGroupToCard()
{
  PatternData patternData;
  SequencerView view;
  String groupName = settingsStoreGetActivePatternGroup();
  uint8_t loadedPatternCount = getLoadedPatternSlotCount();
  int savedCount = 0;

  if (!ensureSdCardPresentForUiAction("Save Group"))
  {
    return false;
  }

  if (groupName.isEmpty())
  {
    showPatternStatus("No active\ngroup name", 2500);
    return false;
  }

  sequencerGetView(view);

  if (view.playing)
  {
    sequencerStopImmediately();
  }

  flushPendingChainSettings();
  syncSequencerChainTargetsFromUi();

  drawBusyPopupNow("Save Group", "Saving " + groupName);

  for (uint8_t slotIndex = 0; slotIndex < loadedPatternCount; slotIndex++)
  {
    String patternName = uiState.chainSlotPatternNames[slotIndex];

    if (patternName.isEmpty())
    {
      patternName = buildPatternNameForSlot(slotIndex);
    }

    sequencerExportPatternFromSlot(slotIndex, patternData);

    patternData.chainEnabled = uiState.chainSlotChainEnabled[slotIndex];
    patternData.chainTarget = uiState.chainSlotTargetPatternNames[slotIndex];
    patternData.chainLength = loadedPatternCount;

    if (!patternData.chainEnabled)
    {
      patternData.chainTarget = "";
    }

    if (!sampleManagerIsSdCardInserted())
    {
      showPatternStatus("Save Group\nSD removed", 3000);
      return false;
    }

    if (!settingsStoreSavePatternToCard(groupName, patternName, patternData))
    {
      showPatternStatus("Save failed\n" + patternName, 2500);
      return false;
    }

    savedCount++;
  }

  uiCardStorageDeleteStalePatterns(groupName, loadedPatternCount);
  saveRuntimeSettingsFromCurrentState();

  uiState.patternGroupDirty = false;

  ESP_LOGI(logTag, "Saved %d in-memory patterns to Card group %s", savedCount, groupName.c_str());

  return true;

} //   saveLoadedPatternGroupToCard()

//-- Draw generic Are-you-sure submenu with No/Yes choices.
static void drawConfirmationScreen(const char* title, int selection)
{
  String yesLine = (selection == 2) ? ">Yes<" : " Yes ";
  String noLine = (selection == 1) ? ">No<" : " No ";

  display.clearScreen(0x0000);
  display.drawHeader(title);
  display.drawCenteredLine("Are you sure?", 74, 0xFFFF, 0x0000);
  display.drawCenteredLine(noLine.c_str(), 112, 0xFFFF, 0x0000);
  display.drawCenteredLine(yesLine.c_str(), 142, 0xFFFF, 0x0000);

} //   drawConfirmationScreen()

//-- Stop playback immediately before storage-related UI actions.
static void stopPlaybackForStorageAction()
{
  SequencerView view;

  sequencerGetView(view);

  if (view.playing)
  {
    sequencerStopImmediately();
  }

} //   stopPlaybackForStorageAction()

//-- Start immediately or stop immediately from the Groovebox screen.
static void handleGrooveboxTransportButton()
{
  SequencerView view;

  sequencerGetView(view);

  if (!view.playing)
  {
    flushPendingChainSettings();
    syncSequencerChainTargetsFromUi();
    sequencerGetView(view);

    if (view.chainEnabled)
    {
      sequencerTogglePlay();
    }
    else
    {
      sequencerStartFromActivePattern();
    }

    return;
  }

  sequencerStopImmediately();

} //   handleGrooveboxTransportButton()

//-- Refresh sample set list from SD card.
static void refreshSampleSetList()
{
  char sampleSetNames[sampleSetListMaxEntries][4] = {0};
  uint8_t sampleSetCount = 0;
  String activeSampleSet = settingsStoreGetActiveSampleSet();

  uiState.sampleSetCount = 0;
  uiState.sampleSetListSelection = 0;
  uiState.sampleSetListFirstVisibleIndex = 0;

  if (!sampleManagerListSampleSets(sampleSetNames, sampleSetListMaxEntries, &sampleSetCount))
  {
    return;
  }

  for (uint8_t sampleSetIndex = 0; sampleSetIndex < sampleSetCount; sampleSetIndex++)
  {
    uiState.sampleSetNames[sampleSetIndex] = String(sampleSetNames[sampleSetIndex]);

    if (uiState.sampleSetNames[sampleSetIndex] == activeSampleSet)
    {
      uiState.sampleSetDisplayItems[sampleSetIndex] =
          fitListRowText("* " + uiState.sampleSetNames[sampleSetIndex]);
      uiState.sampleSetListSelection = sampleSetIndex;
    }
    else
    {
      uiState.sampleSetDisplayItems[sampleSetIndex] =
          fitListRowText("  " + uiState.sampleSetNames[sampleSetIndex]);
    }

    uiState.sampleSetCount++;
  }

} //   refreshSampleSetList()

//-- Load selected sample set from menu without restarting.
static void loadSelectedSampleSetFromMenu()
{
  if (!ensureSdCardPresentForUiAction("Load Samples"))
  {
    uiState.sampleSetListOpen = false;
    uiState.sampleSetListFirstVisibleIndex = 0;
    uiState.dirty = true;
    return;
  }

  if (uiState.sampleSetCount <= 0 || uiState.sampleSetListSelection < 0 ||
      uiState.sampleSetListSelection >= uiState.sampleSetCount)
  {
    showPatternStatus("No sample set", 2000);
    return;
  }

  String selectedSampleSet = uiState.sampleSetNames[uiState.sampleSetListSelection];

  stopPlaybackForStorageAction();
  audioEngineStopAllVoices();

  drawBusyPopupNow("Load Samples", "Loading " + selectedSampleSet);

  if (!sampleManagerIsSdCardInserted())
  {
    showPatternStatus("Load Samples\nSD removed", 3000);
    uiState.sampleSetListOpen = false;
    uiState.sampleSetListFirstVisibleIndex = 0;
    uiState.dirty = true;
    return;
  }

  if (!sampleManagerLoadSampleSet(selectedSampleSet.c_str()))
  {
    showPatternStatus("Load sample set\nfailed", 2000);
    uiState.sampleSetListOpen = false;
    uiState.sampleSetListFirstVisibleIndex = 0;
    uiState.dirty = true;
    return;
  }

  if (!settingsStoreSetActiveSampleSet(selectedSampleSet.c_str()))
  {
    showPatternStatus("Save sample set\nfailed", 2000);
  }

  refreshSampleSetList();

  uiState.sampleSetListOpen = false;
  uiState.sampleSetListFirstVisibleIndex = 0;
  uiState.dirty = true;

} //   loadSelectedSampleSetFromMenu()

//-- Draw Card Storage submenu.
static void drawCardStorageMenu()
{
  uiCardStorageMenuDraw(display, uiState.cardStorageMenuSelection,
                        uiState.cardStorageMenuFirstVisibleIndex, uiState.patternGroupDirty);

  if (uiState.patternStatusOpen)
  {
    drawPatternStatusPopupOverlay();
  }

} //   drawCardStorageMenu()

//-- Draw required system settings menu.
static void drawSystemSettingsScreen()
{
  // Card Storage is a submenu, not a replacement for System Settings
  if (uiState.cardStorageMenuOpen)
  {
    drawCardStorageMenu();
    return;
  }
  if (uiState.eraseWifiRestartPending)
  {
    display.drawWifiPortalScreen("Erasing credentials", "Restart Groovebox", "", "");
    return;
  }

  if (uiState.wifiManagerWaitingForCredentials)
  {
    String apSsid = systemManagerGetPortalApSsid();
    String line2 = String("Connect to ") + apSsid;

    display.drawWifiPortalScreen("WiFi portal started", line2.c_str(), "Enter credentials",
                                 "Waiting...");
    return;
  }

  if (uiState.eraseWifiConfirmOpen)
  {
    drawConfirmationScreen("Erase WiFi Credentials", uiState.eraseWifiConfirmSelection);
    return;
  }

  if (uiState.wifiManagerConfirmOpen)
  {
    drawConfirmationScreen("Start WiFi Manager", uiState.wifiManagerConfirmSelection);
    return;
  }
  //----
  if (uiState.sampleSetListOpen)
  {
    int itemCount = uiState.sampleSetCount;

    if (itemCount <= 0)
    {
      uiState.sampleSetDisplayItems[0] = "(No sample sets)";
      itemCount = 1;
      uiState.sampleSetListSelection = 0;
    }
    else
    {
      uiUpdateListFirstVisibleIndex(uiState.sampleSetListSelection, itemCount,
                                    uiState.sampleSetListFirstVisibleIndex);
    }

    display.drawListScreen("Load Sample Set", uiState.sampleSetDisplayItems,
                           static_cast<size_t>(itemCount), uiState.sampleSetListSelection,
                           uiState.sampleSetListFirstVisibleIndex);

    if (uiState.patternStatusOpen)
    {
      drawPatternStatusPopupOverlay();
    }

    return;
  }
  //----

  if (uiState.patternListOpen)
  {
    if (uiState.patternListNeedsRefresh)
    {
      refreshPatternList();
      uiState.patternListNeedsRefresh = false;
    }

    int itemCount = uiState.patternCount;
    bool activeMarked = false;
    const char* title;

    if (uiState.patternDeleteMode)
    {
      title = (uiState.patternListSourceFilter == patternListModeCardGroups) ? "Delete Group"
                                                                             : "Delete Pattern";
    }
    else
    {
      title = (uiState.patternListSourceFilter == patternListModeCardGroups) ? "Load Group"
                                                                             : "Load Pattern";
    }

    if (itemCount <= 0)
    {
      uiState.patternListDisplayItems[0] = "(No patterns found)";
      itemCount = 1;
      uiState.patternListSelection = 0;
    }
    else
    {
      for (int itemIndex = 0; itemIndex < itemCount; itemIndex++)
      {
        String patternName = uiState.patternNames[itemIndex];
        String lineText;

        if (uiState.patternDeleteMode || uiState.patternListSourceFilter < 0)
        {
          lineText = (uiState.patternSources[itemIndex] == PatternEntrySource::Card) ? "Card:  "
                                                                                     : "Local: ";
        }

        lineText += patternName;

        if (uiState.patternHasChainTarget[itemIndex] &&
            !uiState.patternChainTargets[itemIndex].isEmpty())
        {
          lineText += " -> ";
          lineText += uiState.patternChainTargets[itemIndex];
        }

        if (!activeMarked && !uiState.activePatternName.isEmpty() &&
            patternName == uiState.activePatternName)
        {
          lineText += " *";
          activeMarked = true;
        }

        uiState.patternListDisplayItems[itemIndex] = fitListRowText(lineText);
      }

      uiUpdateListFirstVisibleIndex(uiState.patternListSelection, itemCount,
                                    uiState.patternListFirstVisibleIndex);
    }

    display.drawListScreen(title, uiState.patternListDisplayItems, static_cast<size_t>(itemCount),
                           uiState.patternListSelection, uiState.patternListFirstVisibleIndex);

    if (uiState.patternStatusOpen)
    {
      drawPatternStatusPopupOverlay();
    }

    return;
  }

  uiSystemSettingsMenuDraw(
      uiState.menuSelection, uiState.menuFirstVisibleIndex, systemManagerGetSsid(),
      systemManagerGetIpAddress(), systemManagerGetMacAddress(),
      colorProfiles[displayGetThemeColorIndex()].colorName, displayGetRotation(),
      input.getEncoderDirectionReversed(), uiState.patternGroupDirty);

  if (uiState.patternStatusOpen)
  {
    drawPatternStatusPopupOverlay();
  }

} //   drawSystemSettingsScreen()

//-- Draw the main Groovebox sequencer screen.
static void drawSequencerScreen()
{
  SequencerView view;

  sequencerGetView(view);

  uiGrooveboxScreenDraw(
      display, view, trackNames, uiState.parameterPageIndex, uiState.tempoEditOpen,
      uiState.tempoEditSelection, uiState.tempoEditValueEdit, uiState.masterGainPercent,
      uiState.editPopupOpen, uiState.editPopupSelection, uiState.editPopupValueEdit,
      uiState.editPopupChainFocus, uiState.chainTargetValid, uiState.chainTargetPatternName,
      uiState.chainSlotTargetPatternNames, uiState.chainSlotPatternNames, lastSequencerFooterLine,
      sequencerScreenDrawn);

} //   drawSequencerScreen()

//-- Redraw only the Edit Track popup overlay.
static void drawEditPopupOverlayOnly()
{
  SequencerView view;

  sequencerGetView(view);

  uiGrooveboxScreenDrawEditPopupOverlayOnly(
      display, view, trackNames, uiState.editPopupSelection, uiState.editPopupValueEdit,
      uiState.editPopupChainFocus, uiState.chainTargetValid, uiState.chainTargetPatternName);

} //   drawEditPopupOverlayOnly()

//-- Update only the dynamic Groovebox footer row while running.
static void drawSequencerFooterUpdate(const SequencerView& view)
{
  uiGrooveboxScreenDrawFooterUpdate(display, view, uiState.chainSlotTargetPatternNames,
                                    uiState.chainSlotPatternNames, lastSequencerFooterLine);

} //   drawSequencerFooterUpdate()

//-- Execute selected System Settings menu action.
static void executeMenuAction()
{
  int activeThemeIndex;
  int nextThemeIndex;
  int nextRotation;

  if (uiState.menuSelection == 3)
  {
    saveLoadedPatternGroupToCard();
  }
  else if (uiState.menuSelection == 4)
  {
    addPatternInMemory();
  }
  else if (uiState.menuSelection == 5)
  {
    openDeletePatternFromMemory();
  }
  else if (uiState.menuSelection == 6)
  {
    uiState.cardStorageMenuOpen = true;
    uiState.cardStorageMenuSelection = 0;
    uiState.cardStorageMenuFirstVisibleIndex = 0;
    uiState.dirty = true;
    return;
  }
  else if (uiState.menuSelection == 7)
  {
    SequencerView view;

    if (!ensureSdCardPresentForUiAction("Load Samples"))
    {
      return;
    }

    sequencerGetView(view);

    if (view.playing)
    {
      sequencerStopImmediately();
    }

    refreshSampleSetList();
    uiState.sampleSetListOpen = true;
    uiState.dirty = true;
    return;
  }
  else if (uiState.menuSelection == 8)
  {
    uiState.eraseWifiConfirmOpen = true;
    uiState.eraseWifiConfirmSelection = 1;
  }
  else if (uiState.menuSelection == 9)
  {
    uiState.wifiManagerConfirmOpen = true;
    uiState.wifiManagerConfirmSelection = 1;
  }
  else if (uiState.menuSelection == 10)
  {
    activeThemeIndex = displayGetThemeColorIndex();
    nextThemeIndex = (activeThemeIndex + 1) % colorProfileCount;

    displaySetThemeColorIndex(nextThemeIndex);
    saveRuntimeSettingsFromCurrentState();
  }
  else if (uiState.menuSelection == 11)
  {
    nextRotation = (displayGetRotation() == 1) ? 3 : 1;

    displaySetRotation(nextRotation);
    saveRuntimeSettingsFromCurrentState();
  }
  else if (uiState.menuSelection == 12)
  {
    input.setEncoderDirectionReversed(!input.getEncoderDirectionReversed());
    saveRuntimeSettingsFromCurrentState();
  }
  else if (uiState.menuSelection == 13)
  {
    systemManagerQueueCommand(SystemCommand::restartNow);
  }
  else if (uiState.menuSelection == 14)
  {
    uiState.menuOpen = false;
  }

} //   executeMenuAction()

//-- Initialize UI state and load persisted Card pattern group from NVS.
void uiManagerInit()
{
  RuntimeSettings runtimeSettings;
  String activeGroupName;
  bool startupGroupLoaded = false;

  uiState.menuOpen = false;
  uiState.tempoEditOpen = false;
  uiState.editPopupOpen = false;
  uiState.editPopupValueEdit = false;
  uiState.editPopupChainFocus = chainPopupFocusEnable;
  uiState.tempoEditSelection = 0;
  uiState.editPopupSelection = 0;
  uiState.wifiManagerConfirmOpen = false;
  uiState.eraseWifiConfirmOpen = false;
  uiState.patternListOpen = false;
  uiState.patternDeleteMode = false;
  uiState.patternListSourceFilter = -1;
  uiState.patternListNeedsRefresh = true;
  uiState.sampleSetListOpen = false;
  uiState.patternStatusOpen = false;
  uiState.wifiManagerWaitingForCredentials = false;
  uiState.wifiManagerPortalSeenActive = false;
  uiState.eraseWifiRestartPending = false;
  uiState.wifiManagerConfirmSelection = 0;
  uiState.eraseWifiConfirmSelection = 0;
  uiState.patternListSelection = 0;
  uiState.menuFirstVisibleIndex = 0;
  uiState.patternListFirstVisibleIndex = 0;
  uiState.sampleSetListSelection = 0;
  uiState.sampleSetListFirstVisibleIndex = 0;
  uiState.sampleSetCount = 0;
  uiState.patternCount = 0;
  uiState.patternStatusUntilMs = 0;
  uiState.eraseWifiRestartAtMs = 0;
  uiState.menuSelection = settingsEntryCount - 1;
  uiState.lastDrawMs = 0;
  uiState.dirty = true;
  uiState.parameterPageIndex = parameterPageTrig;
  uiState.activePatternName = "";
  uiState.patternStatusText = "";
  uiState.chainTargetPatternName = "";
  uiState.chainTargetValid = false;
  uiState.chainSettingsDirty = false;
  uiState.chainSeriesPatternCount = 0;
  uiState.chainSeriesPatternLetter = '\0';
  uiState.chainSeriesPatternCacheValid = false;
  uiState.localStorageMenuOpen = false;
  uiState.cardStorageMenuOpen = false;
  uiState.cardStorageMenuSelection = 0;
  uiState.cardStorageMenuFirstVisibleIndex = 0;
  uiState.masterGainPercent = settingsStoreGetMasterGainPercent();
  uiState.masterGainDirty = false;
  uiState.tempoEditValueEdit = false;
  uiPatternGroupInputInit();
  audioEngineSetMasterGainPercent(uiState.masterGainPercent);

  lastSequencerStep = 0xFF;
  lastSequencerCursor = 0xFF;
  lastSequencerPlaying = false;
  lastSequencerActivePatternIndex = 0xFF;
  sequencerScreenDrawn = false;
  lastSequencerFooterLine = "";

  for (uint8_t slotIndex = 0; slotIndex < sequencerPatternCount; slotIndex++)
  {
    uiState.chainSlotPatternNames[slotIndex] = "";
    uiState.chainSlotTargetPatternNames[slotIndex] = "";
    uiState.chainSlotChainEnabled[slotIndex] = false;
  }

  for (int patternIndex = 0; patternIndex < patternListMaxEntries; patternIndex++)
  {
    uiState.patternHasChainTarget[patternIndex] = false;
    uiState.patternChainTargets[patternIndex] = "";
  }

  settingsStoreLoadRuntimeSettings(runtimeSettings);

  activeGroupName = settingsStoreGetActivePatternGroup();

  ESP_LOGI(logTag, "Startup active Card pattern group from NVS: %s", activeGroupName.c_str());

  if (!activeGroupName.isEmpty())
  {
    startupGroupLoaded = loadCardPatternGroupIntoMemory(activeGroupName, false);
  }

  refreshPatternList();

  if (!startupGroupLoaded)
  {
    ESP_LOGW(logTag,
             "No startup Card group loaded. Use System Settings -> Card Storage -> Load Pattern");
  }

  display.drawMessage("ESP32 Groovebox", startupGroupLoaded ? activeGroupName.c_str() : "Ready");

} //   uiManagerInit()

//-- Update UI rendering at controlled refresh cadence.
void uiManagerUpdate()
{
  uint32_t nowMs = millis();
  SequencerView view;
  bool footerStateChanged = false;
  bool transportStateChanged = false;

  if (uiState.eraseWifiRestartPending && nowMs >= uiState.eraseWifiRestartAtMs)
  {
    systemManagerQueueCommand(SystemCommand::eraseWifiCredentials);
    uiState.eraseWifiRestartPending = false;
    return;
  }

  if (uiState.wifiManagerWaitingForCredentials)
  {
    if (systemManagerIsWifiPortalActive())
    {
      uiState.wifiManagerPortalSeenActive = true;
    }
    else if (uiState.wifiManagerPortalSeenActive)
    {
      uiState.wifiManagerWaitingForCredentials = false;
      uiState.wifiManagerPortalSeenActive = false;
      uiState.dirty = true;
    }
  }

  if (uiState.patternStatusOpen && nowMs >= uiState.patternStatusUntilMs)
  {
    uiState.patternStatusOpen = false;
    uiState.patternStatusText = "";
    uiState.dirty = true;
  }

  if (!uiState.menuOpen)
  {
    sequencerGetView(view);

    if (view.activePatternIndex != lastSequencerActivePatternIndex)
    {
      syncActivePatternNameFromSlot(view.activePatternIndex);
      loadChainSettingsForActivePattern();
      lastSequencerActivePatternIndex = view.activePatternIndex;
    }

    footerStateChanged =
        (view.currentStep != lastSequencerStep) || (view.cursorStep != lastSequencerCursor);

    transportStateChanged = (view.playing != lastSequencerPlaying);

    if (transportStateChanged)
    {
      uiState.dirty = true;
    }
  }

  if (!uiState.dirty && !uiState.menuOpen && !uiState.tempoEditOpen && !uiState.editPopupOpen &&
      view.playing && footerStateChanged && sequencerScreenDrawn)
  {
    if (nowMs - uiState.lastDrawMs < uiRefreshIntervalMs)
    {
      return;
    }

    uiState.lastDrawMs = nowMs;

    drawSequencerFooterUpdate(view);

    lastSequencerStep = view.currentStep;
    lastSequencerCursor = view.cursorStep;

    return;
  }

  if (!uiState.dirty)
  {
    return;
  }

  if (nowMs - uiState.lastDrawMs < uiRefreshIntervalMs)
  {
    return;
  }

  if (uiState.editPopupOpen && !uiState.menuOpen && !uiState.tempoEditOpen)
  {
    uiState.lastDrawMs = nowMs;

    drawEditPopupOverlayOnly();

    uiState.dirty = false;

    return;
  }

  uiState.lastDrawMs = nowMs;

  if (uiState.menuOpen)
  {
    sequencerScreenDrawn = false;

    if (uiPatternGroupInputIsOpen())
    {
      uiPatternGroupInputDraw(settingsStoreGetActivePatternGroup());
    }
    else
    {
      drawSystemSettingsScreen();
    }
  }
  else
  {
    drawSequencerScreen();

    sequencerGetView(view);

    lastSequencerPlaying = view.playing;
    lastSequencerStep = view.currentStep;
    lastSequencerCursor = view.cursorStep;
    lastSequencerActivePatternIndex = view.activePatternIndex;
  }

  uiState.dirty = false;

} //   uiManagerUpdate()

//-- Handle encoder while pattern group input is open.
static void handlePatternGroupInputEncoderEvent(EncoderEvent encoderEvent)
{
  if (encoderEvent == ENCODER_EVENT_LEFT)
  {
    uiPatternGroupInputRotate(-1);
  }
  else if (encoderEvent == ENCODER_EVENT_RIGHT)
  {
    uiPatternGroupInputRotate(1);
  }
  else if (encoderEvent == ENCODER_EVENT_SHORT_PRESS)
  {
    uiPatternGroupInputAcceptCharacter();
  }
  else if (encoderEvent == ENCODER_EVENT_MEDIUM_PRESS || encoderEvent == ENCODER_EVENT_LONG_PRESS)
  {
    commitPatternGroupNameInput();
  }

  uiState.dirty = true;

} //   handlePatternGroupInputEncoderEvent()

//-- Persist master gain when it changed in Tempo popup.
static void saveMasterGainIfDirty()
{
  if (!uiState.masterGainDirty)
  {
    return;
  }

  settingsStoreSetMasterGainPercent(uiState.masterGainPercent);
  uiState.masterGainDirty = false;

} //   saveMasterGainIfDirty()

//-- Redraw only the Tempo popup overlay.
static void drawTempoEditPopupOnly()
{
  SequencerView view;
  String tempoRows[3];
  char rowBuffer[32];

  sequencerGetView(view);

  if (uiState.tempoEditSelection == 0 && !uiState.tempoEditValueEdit)
  {
    snprintf(rowBuffer, sizeof(rowBuffer), ">BPM<  %03u", static_cast<unsigned>(view.bpm));
  }
  else if (uiState.tempoEditSelection == 0)
  {
    snprintf(rowBuffer, sizeof(rowBuffer), " BPM  >%03u<", static_cast<unsigned>(view.bpm));
  }
  else
  {
    snprintf(rowBuffer, sizeof(rowBuffer), " BPM   %03u", static_cast<unsigned>(view.bpm));
  }

  tempoRows[0] = rowBuffer;

  if (uiState.tempoEditSelection == 1 && !uiState.tempoEditValueEdit)
  {
    snprintf(rowBuffer, sizeof(rowBuffer), ">SW<   %02u%%",
             static_cast<unsigned>(view.swingPercent));
  }
  else if (uiState.tempoEditSelection == 1)
  {
    snprintf(rowBuffer, sizeof(rowBuffer), " SW   >%02u%%<",
             static_cast<unsigned>(view.swingPercent));
  }
  else
  {
    snprintf(rowBuffer, sizeof(rowBuffer), " SW    %02u%%",
             static_cast<unsigned>(view.swingPercent));
  }

  tempoRows[1] = rowBuffer;

  if (uiState.tempoEditSelection == 2 && !uiState.tempoEditValueEdit)
  {
    snprintf(rowBuffer, sizeof(rowBuffer), ">GAIN< %03u%%",
             static_cast<unsigned>(uiState.masterGainPercent));
  }
  else if (uiState.tempoEditSelection == 2)
  {
    snprintf(rowBuffer, sizeof(rowBuffer), " GAIN >%03u%%<",
             static_cast<unsigned>(uiState.masterGainPercent));
  }
  else
  {
    snprintf(rowBuffer, sizeof(rowBuffer), " GAIN  %03u%%",
             static_cast<unsigned>(uiState.masterGainPercent));
  }

  tempoRows[2] = rowBuffer;

  display.drawSelectionOverlay("Tempo", tempoRows, 3, uiState.tempoEditSelection);

} //   drawTempoEditPopupOnly()

//-- Handle tempo edit encoder events.
static void handleTempoEditEncoderEvent(EncoderEvent encoderEvent)
{
  if (encoderEvent == ENCODER_EVENT_LEFT)
  {
    if (!uiState.tempoEditValueEdit)
    {
      uiState.tempoEditSelection--;

      if (uiState.tempoEditSelection < 0)
      {
        uiState.tempoEditSelection = 2;
      }
    }
    else if (uiState.tempoEditSelection == 0)
    {
      sequencerAdjustBpm(-1);
    }
    else if (uiState.tempoEditSelection == 1)
    {
      sequencerAdjustSwing(-1);
    }
    else
    {
      if (uiState.masterGainPercent > 10)
      {
        uiState.masterGainPercent--;
        uiState.masterGainDirty = true;
        audioEngineSetMasterGainPercent(uiState.masterGainPercent);
      }
    }

    drawTempoEditPopupOnly();
    return;
  }
  else if (encoderEvent == ENCODER_EVENT_RIGHT)
  {
    if (!uiState.tempoEditValueEdit)
    {
      uiState.tempoEditSelection++;

      if (uiState.tempoEditSelection > 2)
      {
        uiState.tempoEditSelection = 0;
      }
    }
    else if (uiState.tempoEditSelection == 0)
    {
      sequencerAdjustBpm(1);
    }
    else if (uiState.tempoEditSelection == 1)
    {
      sequencerAdjustSwing(1);
    }
    else
    {
      if (uiState.masterGainPercent < 200)
      {
        uiState.masterGainPercent++;
        uiState.masterGainDirty = true;
        audioEngineSetMasterGainPercent(uiState.masterGainPercent);
      }
    }

    drawTempoEditPopupOnly();
    return;
  }
  else if (encoderEvent == ENCODER_EVENT_SHORT_PRESS)
  {
    if (uiState.tempoEditValueEdit)
    {
      uiState.tempoEditValueEdit = false;
      saveMasterGainIfDirty();
    }
    else
    {
      uiState.tempoEditValueEdit = true;
    }

    drawTempoEditPopupOnly();
    return;
  }
  else if (encoderEvent == ENCODER_EVENT_MEDIUM_PRESS)
  {
    saveMasterGainIfDirty();

    uiState.tempoEditOpen = false;
    uiState.tempoEditSelection = 0;
    uiState.tempoEditValueEdit = false;
    uiState.dirty = true;

    return;
  }

} //   handleTempoEditEncoderEvent()

//-- Handle edit popup encoder events.
static void handleEditPopupEncoderEvent(EncoderEvent encoderEvent)
{
  if (encoderEvent == ENCODER_EVENT_LEFT)
  {
    if (uiState.editPopupValueEdit)
    {
      applyEditPopupValueDelta(-1);
    }
    else
    {
      uiState.editPopupSelection--;

      if (uiState.editPopupSelection < 0)
      {
        uiState.editPopupSelection = editPopupEntryCount - 1;
      }

      uiState.editPopupChainFocus = chainPopupFocusEnable;
      uiState.parameterPageIndex = popupSelectionToParameterPage(uiState.editPopupSelection);
    }
  }
  else if (encoderEvent == ENCODER_EVENT_RIGHT)
  {
    if (uiState.editPopupValueEdit)
    {
      applyEditPopupValueDelta(1);
    }
    else
    {
      uiState.editPopupSelection++;

      if (uiState.editPopupSelection >= editPopupEntryCount)
      {
        uiState.editPopupSelection = 0;
      }

      uiState.editPopupChainFocus = chainPopupFocusEnable;
      uiState.parameterPageIndex = popupSelectionToParameterPage(uiState.editPopupSelection);
    }
  }
  else if (encoderEvent == ENCODER_EVENT_SHORT_PRESS)
  {
    uiState.parameterPageIndex = popupSelectionToParameterPage(uiState.editPopupSelection);

    if (!uiState.editPopupValueEdit)
    {
      uiState.editPopupValueEdit = true;
      uiState.editPopupValueChanged = false;
      uiState.editPopupChainFocus = chainPopupFocusEnable;
    }
    else if (uiState.parameterPageIndex == parameterPageChain)
    {
      uiState.editPopupChainFocus = static_cast<uint8_t>((uiState.editPopupChainFocus + 1U) % 3U);
    }
    else
    {
      finishEditPopupValueEdit();
      flushPendingChainSettings();
    }
  }
  else if (encoderEvent == ENCODER_EVENT_MEDIUM_PRESS || encoderEvent == ENCODER_EVENT_LONG_PRESS)
  {
    closeEditPopupAndReturnToStepNavigation();
  }

  uiState.dirty = true;

} //   handleEditPopupEncoderEvent()

//-- Determine active encoder handling state.
static UiEncoderState getUiEncoderState()
{
  if (uiPatternGroupInputIsOpen())
  {
    return UiEncoderState::PatternGroupInput;
  }

  if (uiState.menuOpen)
  {
    return UiEncoderState::Menu;
  }

  if (uiState.tempoEditOpen)
  {
    return UiEncoderState::TempoEdit;
  }

  if (uiState.editPopupOpen)
  {
    return UiEncoderState::EditPopup;
  }

  return UiEncoderState::Groovebox;

} //   getUiEncoderState()

//-- Handle global long-press encoder actions before state dispatch.
static bool handleGlobalLongPressEncoderEvent(const SequencerView& view)
{
  if (uiState.editPopupOpen)
  {
    closeEditPopupAndReturnToStepNavigation();
    return true;
  }

  if (!uiState.menuOpen && !uiState.tempoEditOpen && view.editMode)
  {
    if (uiState.parameterPageIndex == 0)
    {
      uiState.parameterPageIndex = parameterPageCount - 1;
    }
    else
    {
      uiState.parameterPageIndex--;
    }

    uiState.dirty = true;

    return true;
  }

  if (uiState.wifiManagerWaitingForCredentials)
  {
    systemManagerQueueCommand(SystemCommand::restartNow);
    return true;
  }

  flushPendingChainSettings();

  uiState.menuOpen = !uiState.menuOpen;
  uiState.tempoEditOpen = false;
  uiState.wifiManagerConfirmOpen = false;
  uiState.eraseWifiConfirmOpen = false;
  uiState.patternListOpen = false;
  uiState.patternDeleteMode = false;
  uiState.patternStatusOpen = false;
  uiState.patternStatusText = "";

  if (uiState.menuOpen)
  {
    uiState.menuSelection = settingsFirstActionIndex;
    uiState.menuFirstVisibleIndex = 0;
  }

  uiNormalizeMenuSelection(uiState.menuSelection, settingsEntryCount);
  uiUpdateListFirstVisibleIndex(uiState.menuSelection, settingsEntryCount,
                                uiState.menuFirstVisibleIndex);

  uiState.dirty = true;

  ESP_LOGI(logTag, "Long press toggled settings menu: menuOpen=%d", uiState.menuOpen ? 1 : 0);

  if (uiState.menuOpen)
  {
    display.drawMessage("System Settings", "Opening menu...");
  }

  return true;

} //   handleGlobalLongPressEncoderEvent()

//-- Handle encoder events on the main Groovebox screen.
static void handleGrooveboxEncoderEvent(EncoderEvent encoderEvent, const SequencerView& view)
{
  bool patternWasModified = false;

  if (encoderEvent == ENCODER_EVENT_LEFT)
  {
    if (view.editMode)
    {
      if (uiState.parameterPageIndex == parameterPageTrig)
      {
        sequencerMoveCursor(-1);
      }
      else if (uiState.parameterPageIndex == parameterPageVelocity)
      {
        sequencerAdjustCurrentStepVelocity(-8);
        patternWasModified = true;
      }
      else if (uiState.parameterPageIndex == parameterPagePitch)
      {
        sequencerAdjustCurrentStepLockPitch(-1);
        patternWasModified = true;
      }
      else if (uiState.parameterPageIndex == parameterPageDecay)
      {
        sequencerAdjustCurrentStepLockDecay(-5);
        patternWasModified = true;
      }
      else if (uiState.parameterPageIndex == parameterPageProbability)
      {
        sequencerAdjustCurrentStepProbability(-5);
        patternWasModified = true;
      }
      else if (uiState.parameterPageIndex == parameterPageMute)
      {
        moveGrooveboxCursorAcrossPatterns(-1);
      }
      else
      {
        sequencerAdjustChainLength(-1);
        uiState.chainSettingsDirty = true;
        patternWasModified = true;
      }
    }
    else
    {
      moveGrooveboxCursorAcrossPatterns(-1);
    }
  }
  else if (encoderEvent == ENCODER_EVENT_RIGHT)
  {
    if (view.editMode)
    {
      if (uiState.parameterPageIndex == parameterPageTrig)
      {
        sequencerMoveCursor(1);
      }
      else if (uiState.parameterPageIndex == parameterPageVelocity)
      {
        sequencerAdjustCurrentStepVelocity(8);
        patternWasModified = true;
      }
      else if (uiState.parameterPageIndex == parameterPagePitch)
      {
        sequencerAdjustCurrentStepLockPitch(1);
        patternWasModified = true;
      }
      else if (uiState.parameterPageIndex == parameterPageDecay)
      {
        sequencerAdjustCurrentStepLockDecay(5);
        patternWasModified = true;
      }
      else if (uiState.parameterPageIndex == parameterPageProbability)
      {
        sequencerAdjustCurrentStepProbability(5);
        patternWasModified = true;
      }
      else if (uiState.parameterPageIndex == parameterPageMute)
      {
        moveGrooveboxCursorAcrossPatterns(1);
      }
      else
      {
        sequencerAdjustChainLength(1);
        uiState.chainSettingsDirty = true;
        patternWasModified = true;
      }
    }
    else
    {
      moveGrooveboxCursorAcrossPatterns(1);
    }
  }
  else if (encoderEvent == ENCODER_EVENT_SHORT_PRESS)
  {
    if (!view.editMode)
    {
      sequencerToggleEditMode();
    }
    else
    {
      if (uiState.parameterPageIndex == parameterPageTrig)
      {
        sequencerToggleCurrentStep();
        patternWasModified = true;
      }
      else if (uiState.parameterPageIndex == parameterPageMute)
      {
        sequencerToggleCurrentStepMute();
        patternWasModified = true;
      }
      else if (uiState.parameterPageIndex == parameterPagePitch ||
               uiState.parameterPageIndex == parameterPageDecay)
      {
        sequencerToggleCurrentStepLock();
        patternWasModified = true;
      }
      else if (uiState.parameterPageIndex == parameterPageChain)
      {
        sequencerToggleChainEnabled();
        uiState.chainSettingsDirty = true;
        patternWasModified = true;
      }
      else
      {
        sequencerToggleCurrentStep();
        patternWasModified = true;
      }
    }
  }
  else if (encoderEvent == ENCODER_EVENT_MEDIUM_PRESS)
  {
    if (view.editMode)
    {
      openEditPopupForCurrentStep();
    }
    else
    {
      uiState.tempoEditOpen = true;
      uiState.tempoEditSelection = 0;
      uiState.tempoEditValueEdit = false;
    }
  }

  if (patternWasModified)
  {
    uiState.patternGroupDirty = true;
  }

  uiState.dirty = true;

} //   handleGrooveboxEncoderEvent()

//-- Handle Card Storage submenu encoder events.
static void handleCardStorageMenuEncoderEvent(EncoderEvent encoderEvent)
{
  if (encoderEvent == ENCODER_EVENT_LEFT)
  {
    uiState.cardStorageMenuSelection--;

    if (uiState.cardStorageMenuSelection < 0)
    {
      uiState.cardStorageMenuSelection = cardStorageMenuEntryCount - 1;
    }

    uiUpdateListFirstVisibleIndex(uiState.cardStorageMenuSelection, cardStorageMenuEntryCount,
                                  uiState.cardStorageMenuFirstVisibleIndex);
  }
  else if (encoderEvent == ENCODER_EVENT_RIGHT)
  {
    uiState.cardStorageMenuSelection++;

    if (uiState.cardStorageMenuSelection >= cardStorageMenuEntryCount)
    {
      uiState.cardStorageMenuSelection = 0;
    }

    uiUpdateListFirstVisibleIndex(uiState.cardStorageMenuSelection, cardStorageMenuEntryCount,
                                  uiState.cardStorageMenuFirstVisibleIndex);
  }
  else if (encoderEvent == ENCODER_EVENT_SHORT_PRESS || encoderEvent == ENCODER_EVENT_MEDIUM_PRESS)
  {
    if (uiState.cardStorageMenuSelection == 0)
    {
      saveLoadedPatternGroupToCard();
    }
    else if (uiState.cardStorageMenuSelection == 1)
    {
      uiState.patternListOpen = true;
      uiState.patternDeleteMode = false;
      uiState.patternListSourceFilter = patternListModeCardGroups;
      uiState.patternListSelection = 0;
      uiState.patternListFirstVisibleIndex = 0;
      uiState.patternListNeedsRefresh = true;
      uiState.cardStorageMenuOpen = false;
    }
    else if (uiState.cardStorageMenuSelection == 2)
    {
      uiPatternGroupInputOpenNewGroup();
      uiState.dirty = true;
    }
    else if (uiState.cardStorageMenuSelection == 3)
    {
      uiPatternGroupInputOpen(false);
      uiState.dirty = true;
    }
    else if (uiState.cardStorageMenuSelection == 4)
    {
      uiPatternGroupInputOpen(true);
      uiState.dirty = true;
    }
    else if (uiState.cardStorageMenuSelection == 5)
    {
      uiState.patternListOpen = true;
      uiState.patternDeleteMode = true;
      uiState.patternListSourceFilter = patternListModeCardGroups;
      uiState.patternListSelection = 0;
      uiState.patternListFirstVisibleIndex = 0;
      uiState.patternListNeedsRefresh = true;
      uiState.cardStorageMenuOpen = false;
    }
    else if (uiState.cardStorageMenuSelection == 6)
    {
      uiState.cardStorageMenuOpen = false;
      uiState.cardStorageMenuSelection = 0;
      uiState.cardStorageMenuFirstVisibleIndex = 0;
    }
  }

  uiState.dirty = true;

} //   handleCardStorageMenuEncoderEvent()

//-- Handle Sample Set list encoder events.
static void handleSampleSetListEncoderEvent(EncoderEvent encoderEvent)
{
  if (encoderEvent == ENCODER_EVENT_LEFT)
  {
    if (uiState.sampleSetCount > 0)
    {
      uiState.sampleSetListSelection--;

      if (uiState.sampleSetListSelection < 0)
      {
        uiState.sampleSetListSelection = uiState.sampleSetCount - 1;
      }

      uiUpdateListFirstVisibleIndex(uiState.sampleSetListSelection, uiState.sampleSetCount,
                                    uiState.sampleSetListFirstVisibleIndex);
    }
  }
  else if (encoderEvent == ENCODER_EVENT_RIGHT)
  {
    if (uiState.sampleSetCount > 0)
    {
      uiState.sampleSetListSelection++;

      if (uiState.sampleSetListSelection >= uiState.sampleSetCount)
      {
        uiState.sampleSetListSelection = 0;
      }

      uiUpdateListFirstVisibleIndex(uiState.sampleSetListSelection, uiState.sampleSetCount,
                                    uiState.sampleSetListFirstVisibleIndex);
    }
  }
  else if (encoderEvent == ENCODER_EVENT_SHORT_PRESS || encoderEvent == ENCODER_EVENT_MEDIUM_PRESS)
  {
    loadSelectedSampleSetFromMenu();
  }

  uiState.dirty = true;

} //   handleSampleSetListEncoderEvent()

//-- Handle pattern list encoder events.
static void handlePatternListEncoderEvent(EncoderEvent encoderEvent)
{
  if (encoderEvent == ENCODER_EVENT_LEFT)
  {
    if (uiState.patternCount > 0)
    {
      uiState.patternListSelection--;

      if (uiState.patternListSelection < 0)
      {
        uiState.patternListSelection = uiState.patternCount - 1;
      }

      uiUpdateListFirstVisibleIndex(uiState.patternListSelection, uiState.patternCount,
                                    uiState.patternListFirstVisibleIndex);
    }
  }
  else if (encoderEvent == ENCODER_EVENT_RIGHT)
  {
    if (uiState.patternCount > 0)
    {
      uiState.patternListSelection++;

      if (uiState.patternListSelection >= uiState.patternCount)
      {
        uiState.patternListSelection = 0;
      }

      uiUpdateListFirstVisibleIndex(uiState.patternListSelection, uiState.patternCount,
                                    uiState.patternListFirstVisibleIndex);
    }
  }
  else if (encoderEvent == ENCODER_EVENT_SHORT_PRESS || encoderEvent == ENCODER_EVENT_MEDIUM_PRESS)
  {
    if (uiState.patternCount > 0)
    {
      if (uiState.patternDeleteMode)
      {
        String deletedName;
        PatternEntrySource deletedSource = PatternEntrySource::Local;

        if (deleteSelectedPattern(&deletedName, &deletedSource))
        {
          if (deletedSource == PatternEntrySource::Card)
          {
            showPatternStatus(deletedName + " group deleted\nfrom SD card", 2000);
          }
          else
          {
            showPatternStatus(deletedName + " deleted from\nLocal storage", 2000);
          }
        }
        else
        {
          showPatternStatus("Delete failed", 2000);
        }

        uiState.patternListNeedsRefresh = true;
        refreshPatternList();

        if (uiState.patternCount == 0)
        {
          uiState.patternListOpen = false;
          uiState.patternListFirstVisibleIndex = 0;
        }
      }
      else if (uiState.patternListSourceFilter == patternListModeCardGroups)
      {
        if (loadSelectedCardPatternGroup())
        {
          uiState.patternListOpen = false;
          uiState.patternListSourceFilter = -1;
          uiState.patternListFirstVisibleIndex = 0;
        }
      }
      else if (uiState.patternListSourceFilter == patternListModeMemoryPatterns)
      {
        if (loadSelectedPattern())
        {
          uiState.menuOpen = false;
          uiState.patternListOpen = false;
          uiState.patternListFirstVisibleIndex = 0;
        }
      }
    }
  }

  uiState.dirty = true;

} //   handlePatternListEncoderEvent()

//-- Handle WiFi Manager confirmation encoder events.
static void handleWifiConfirmEncoderEvent(EncoderEvent encoderEvent)
{
  if (encoderEvent == ENCODER_EVENT_LEFT)
  {
    uiState.wifiManagerConfirmSelection = (uiState.wifiManagerConfirmSelection <= 1) ? 2 : 1;
  }
  else if (encoderEvent == ENCODER_EVENT_RIGHT)
  {
    uiState.wifiManagerConfirmSelection = (uiState.wifiManagerConfirmSelection >= 2) ? 1 : 2;
  }
  else if (encoderEvent == ENCODER_EVENT_SHORT_PRESS || encoderEvent == ENCODER_EVENT_MEDIUM_PRESS)
  {
    if (uiState.wifiManagerConfirmSelection == 2)
    {
      systemManagerQueueCommand(SystemCommand::startWifiManager);
      uiState.wifiManagerWaitingForCredentials = true;
      uiState.wifiManagerPortalSeenActive = false;
    }

    uiState.wifiManagerConfirmOpen = false;
  }

  uiState.dirty = true;

} //   handleWifiConfirmEncoderEvent()

//-- Handle Erase WiFi confirmation encoder events.
static void handleEraseWifiConfirmEncoderEvent(EncoderEvent encoderEvent)
{
  if (encoderEvent == ENCODER_EVENT_LEFT)
  {
    uiState.eraseWifiConfirmSelection = (uiState.eraseWifiConfirmSelection <= 1) ? 2 : 1;
  }
  else if (encoderEvent == ENCODER_EVENT_RIGHT)
  {
    uiState.eraseWifiConfirmSelection = (uiState.eraseWifiConfirmSelection >= 2) ? 1 : 2;
  }
  else if (encoderEvent == ENCODER_EVENT_SHORT_PRESS || encoderEvent == ENCODER_EVENT_MEDIUM_PRESS)
  {
    if (uiState.eraseWifiConfirmSelection == 2)
    {
      uiState.eraseWifiRestartPending = true;
      uiState.eraseWifiRestartAtMs = millis() + 1200;
    }

    uiState.eraseWifiConfirmOpen = false;
  }

  uiState.dirty = true;

} //   handleEraseWifiConfirmEncoderEvent()

//-- Handle root System Settings menu encoder events.
static void handleRootSettingsMenuEncoderEvent(EncoderEvent encoderEvent)
{
  if (encoderEvent == ENCODER_EVENT_LEFT)
  {
    uiState.menuSelection--;
    uiNormalizeMenuSelection(uiState.menuSelection, settingsEntryCount);
    uiUpdateListFirstVisibleIndex(uiState.menuSelection, settingsEntryCount,
                                  uiState.menuFirstVisibleIndex);
  }
  else if (encoderEvent == ENCODER_EVENT_RIGHT)
  {
    uiState.menuSelection++;
    uiNormalizeMenuSelection(uiState.menuSelection, settingsEntryCount);
    uiUpdateListFirstVisibleIndex(uiState.menuSelection, settingsEntryCount,
                                  uiState.menuFirstVisibleIndex);
  }
  else if (encoderEvent == ENCODER_EVENT_SHORT_PRESS || encoderEvent == ENCODER_EVENT_MEDIUM_PRESS)
  {
    executeMenuAction();
  }

  uiState.dirty = true;

} //   handleRootSettingsMenuEncoderEvent()

//-- Handle encoder events while System Settings or submenus are open.
static void handleMenuEncoderEvent(EncoderEvent encoderEvent)
{
  if (uiState.patternStatusOpen)
  {
    uiState.dirty = true;
    return;
  }

  if (uiState.cardStorageMenuOpen)
  {
    handleCardStorageMenuEncoderEvent(encoderEvent);
    return;
  }

  if (uiState.sampleSetListOpen)
  {
    handleSampleSetListEncoderEvent(encoderEvent);
    return;
  }

  if (uiState.patternListOpen)
  {
    handlePatternListEncoderEvent(encoderEvent);
    return;
  }

  if (uiState.wifiManagerConfirmOpen)
  {
    handleWifiConfirmEncoderEvent(encoderEvent);
    return;
  }

  if (uiState.eraseWifiConfirmOpen)
  {
    handleEraseWifiConfirmEncoderEvent(encoderEvent);
    return;
  }

  if (!uiState.wifiManagerWaitingForCredentials)
  {
    handleRootSettingsMenuEncoderEvent(encoderEvent);
    return;
  }

  uiState.dirty = true;

} //   handleMenuEncoderEvent()

//-- Route encoder events into UI state machine.
void uiManagerHandleEncoderEvent(EncoderEvent encoderEvent)
{
  SequencerView view;
  UiEncoderState encoderState;

  if (encoderEvent == ENCODER_EVENT_NONE)
  {
    return;
  }

  sequencerGetView(view);

  encoderState = getUiEncoderState();

  ESP_LOGI(logTag, "Encoder event=%d, menuOpen=%d", static_cast<int>(encoderEvent),
           uiState.menuOpen ? 1 : 0);

  if (encoderEvent == ENCODER_EVENT_LONG_PRESS && encoderState != UiEncoderState::PatternGroupInput)
  {
    if (handleGlobalLongPressEncoderEvent(view))
    {
      return;
    }
  }

  switch (encoderState)
  {
  case UiEncoderState::PatternGroupInput:
    handlePatternGroupInputEncoderEvent(encoderEvent);
    break;

  case UiEncoderState::Menu:
    handleMenuEncoderEvent(encoderEvent);
    break;

  case UiEncoderState::TempoEdit:
    handleTempoEditEncoderEvent(encoderEvent);
    break;

  case UiEncoderState::EditPopup:
    handleEditPopupEncoderEvent(encoderEvent);
    break;

  case UiEncoderState::Groovebox:
  default:
    handleGrooveboxEncoderEvent(encoderEvent, view);
    break;
  }

} //   uiManagerHandleEncoderEvent()

//-- Handle auxiliary KEY0 button events.
void uiManagerHandleAuxButtonEvent(ButtonEvent buttonEvent)
{
  if (buttonEvent == BUTTON_EVENT_NONE)
  {
    return;
  }

  if (uiPatternGroupInputIsOpen())
  {
    if (buttonEvent == BUTTON_EVENT_SHORT_PRESS)
    {
      uiPatternGroupInputBackspaceOrCancel();
    }

    return;
  }

  if (uiState.menuOpen)
  {
    if (buttonEvent == BUTTON_EVENT_SHORT_PRESS)
    {
      if (uiState.cardStorageMenuOpen)
      {
        uiState.cardStorageMenuOpen = false;
        uiState.cardStorageMenuSelection = 0;
        uiState.cardStorageMenuFirstVisibleIndex = 0;
      }
      else if (uiState.sampleSetListOpen)
      {
        uiState.sampleSetListOpen = false;
        uiState.sampleSetListFirstVisibleIndex = 0;
      }
      else if (uiState.patternListOpen)
      {
        uiState.patternListOpen = false;
        uiState.patternDeleteMode = false;
        uiState.patternListFirstVisibleIndex = 0;
      }
      else if (uiState.wifiManagerConfirmOpen)
      {
        uiState.wifiManagerConfirmOpen = false;
      }
      else if (uiState.eraseWifiConfirmOpen)
      {
        uiState.eraseWifiConfirmOpen = false;
      }
      else if (uiState.wifiManagerWaitingForCredentials)
      {
        //-- Stay on waiting screen until credentials are entered or portal closes.
      }
      else
      {
        flushPendingChainSettings();

        uiState.menuOpen = false;
        uiState.tempoEditOpen = false;
        uiState.editPopupOpen = false;
        uiState.editPopupValueEdit = false;
        uiState.editPopupChainFocus = chainPopupFocusEnable;
        uiState.tempoEditSelection = 0;
      }

      uiState.dirty = true;
    }

    return;
  }

  if (uiState.tempoEditOpen)
  {
    if (buttonEvent == BUTTON_EVENT_SHORT_PRESS || buttonEvent == BUTTON_EVENT_MEDIUM_PRESS ||
        buttonEvent == BUTTON_EVENT_LONG_PRESS)
    {
      uiState.tempoEditOpen = false;
      uiState.tempoEditSelection = 0;
      uiState.dirty = true;
    }

    return;
  }

  if (uiState.editPopupOpen)
  {
    if (buttonEvent == BUTTON_EVENT_SHORT_PRESS || buttonEvent == BUTTON_EVENT_MEDIUM_PRESS ||
        buttonEvent == BUTTON_EVENT_LONG_PRESS)
    {
      closeEditPopupAndReturnToStepNavigation();
    }

    return;
  }

  SequencerView view;

  sequencerGetView(view);

  if (buttonEvent == BUTTON_EVENT_SHORT_PRESS)
  {
    if (view.editMode)
    {
      flushPendingChainSettings();

      sequencerToggleEditMode();

      uiState.parameterPageIndex = parameterPageTrig;
      uiState.editPopupOpen = false;
      uiState.editPopupValueEdit = false;
      uiState.editPopupChainFocus = chainPopupFocusEnable;
    }
    else
    {
      handleGrooveboxTransportButton();
    }
  }
  else if (buttonEvent == BUTTON_EVENT_MEDIUM_PRESS)
  {
    if (view.editMode)
    {
      openEditPopupForCurrentStep();
    }
    else
    {
      uiState.tempoEditOpen = true;
      uiState.tempoEditSelection = 0;
      uiState.tempoEditValueEdit = false;
    }
  }
  else if (buttonEvent == BUTTON_EVENT_LONG_PRESS)
  {
    sequencerToggleMuteForSelectedTrack();
    uiState.patternGroupDirty = true;
  }

  uiState.dirty = true;

} //   uiManagerHandleAuxButtonEvent()

//
// Query whether pattern group has unsaved changes.
//
bool uiManagerIsPatternGroupDirty()
{
  return uiState.patternGroupDirty;
} //   uiManagerIsPatternGroupDirty()

//
// Set the pattern group dirty flag explicitly.
//
void uiManagerSetPatternGroupDirty(bool dirty)
{
  uiState.patternGroupDirty = dirty;
} //   uiManagerSetPatternGroupDirty()

//
// Get count of currently loaded patterns in active group.
//
uint8_t uiManagerGetLoadedPatternCount()
{
  return getLoadedPatternSlotCount();
} //   uiManagerGetLoadedPatternCount()

//
// Get pattern name string for a given slot index.
//
String uiManagerGetPatternNameForSlot(uint8_t slotIndex)
{
  if (slotIndex < sequencerPatternCount)
  {
    return uiState.chainSlotPatternNames[slotIndex];
  }
  return "";
} //   uiManagerGetPatternNameForSlot()

//
// Get pattern chain target for a given slot index.
//
String uiManagerGetPatternChainTargetForSlot(uint8_t slotIndex)
{
  if (slotIndex < sequencerPatternCount)
  {
    return uiState.chainSlotTargetPatternNames[slotIndex];
  }
  return "";
} //   uiManagerGetPatternChainTargetForSlot()

//
// Query whether chain is enabled for a given slot index.
//
bool uiManagerGetPatternChainEnabledForSlot(uint8_t slotIndex)
{
  if (slotIndex < sequencerPatternCount)
  {
    return uiState.chainSlotChainEnabled[slotIndex];
  }
  return false;
} //   uiManagerGetPatternChainEnabledForSlot()

//
// Load a pattern group from SD card into memory.
//
bool uiManagerLoadPatternGroup(const String& groupName)
{
  return loadCardPatternGroupIntoMemory(groupName, false);
} //   uiManagerLoadPatternGroup()

//
// Save the active pattern group to SD card.
//
bool uiManagerSavePatternGroup()
{
  return saveLoadedPatternGroupToCard();
} //   uiManagerSavePatternGroup()
